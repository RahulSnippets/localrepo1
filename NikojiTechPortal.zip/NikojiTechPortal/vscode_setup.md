# VS Code Development Setup Guide for Nikoji Technologies

## Prerequisites

1. **Install Required Software**
   - Python 3.8+ (https://python.org)
   - PostgreSQL 12+ (https://postgresql.org)
   - VS Code (https://code.visualstudio.com)
   - Git (https://git-scm.com)

## Step 1: VS Code Extensions

Install these essential extensions:

1. **Python Development**
   - Python (Microsoft)
   - Python Docstring Generator
   - Python Indent
   - Pylance

2. **Database Management**
   - PostgreSQL (Chris Kolkman)
   - SQLTools
   - SQLTools PostgreSQL/Cockroach Driver

3. **Web Development**
   - HTML CSS Support
   - Auto Rename Tag
   - Live Server
   - Prettier - Code formatter

4. **General Development**
   - GitLens
   - Material Icon Theme
   - Bracket Pair Colorizer

## Step 2: Project Setup

1. **Clone or Create Project**
   ```bash
   git clone <repository-url>
   cd nikoji-technologies
   ```

2. **Create Virtual Environment**
   ```bash
   python -m venv venv
   
   # On Windows
   venv\Scripts\activate
   
   # On macOS/Linux
   source venv/bin/activate
   ```

3. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

## Step 3: PostgreSQL Setup

1. **Install PostgreSQL**
   - Download from official website
   - Follow installation wizard
   - Note the superuser password

2. **Create Database**
   ```sql
   -- Connect to PostgreSQL as superuser
   psql -U postgres
   
   -- Create database
   CREATE DATABASE nikoji_tech_db;
   
   -- Create user
   CREATE USER nikoji_user WITH PASSWORD 'your_secure_password';
   
   -- Grant privileges
   GRANT ALL PRIVILEGES ON DATABASE nikoji_tech_db TO nikoji_user;
   
   -- Exit
   \q
   ```

3. **Run Database Setup**
   ```bash
   psql -U nikoji_user -d nikoji_tech_db -f cpanel_database_setup.sql
   ```

## Step 4: Environment Configuration

1. **Create .env File**
   ```bash
   touch .env
   ```

2. **Add Environment Variables**
   ```env
   DATABASE_URL=postgresql://nikoji_user:your_secure_password@localhost:5432/nikoji_tech_db
   PGHOST=localhost
   PGPORT=5432
   PGDATABASE=nikoji_tech_db
   PGUSER=nikoji_user
   PGPASSWORD=your_secure_password
   SESSION_SECRET=your_random_secret_key_minimum_32_characters
   FLASK_ENV=development
   FLASK_DEBUG=true
   ```

3. **Load Environment Variables**
   - Install python-dotenv: `pip install python-dotenv`
   - Add to app.py:
   ```python
   from dotenv import load_dotenv
   load_dotenv()
   ```

## Step 5: VS Code Workspace Configuration

1. **Create .vscode/settings.json**
   ```json
   {
     "python.defaultInterpreterPath": "./venv/bin/python",
     "python.formatting.provider": "black",
     "python.linting.enabled": true,
     "python.linting.pylintEnabled": true,
     "editor.formatOnSave": true,
     "files.exclude": {
       "**/__pycache__": true,
       "**/*.pyc": true
     }
   }
   ```

2. **Create .vscode/launch.json**
   ```json
   {
     "version": "0.2.0",
     "configurations": [
       {
         "name": "Flask App",
         "type": "python",
         "request": "launch",
         "program": "${workspaceFolder}/main.py",
         "env": {
           "FLASK_ENV": "development",
           "FLASK_DEBUG": "1"
         },
         "console": "integratedTerminal",
         "justMyCode": true
       }
     ]
   }
   ```

## Step 6: Database Connection in VS Code

1. **Configure SQLTools**
   - Open Command Palette (Ctrl+Shift+P)
   - Type "SQLTools: Add New Connection"
   - Select PostgreSQL
   - Enter connection details:
     ```
     Connection Name: Nikoji Technologies DB
     Server: localhost
     Port: 5432
     Database: nikoji_tech_db
     Username: nikoji_user
     Password: your_secure_password
     ```

2. **Test Connection**
   - Click "Test Connection"
   - Save the connection
   - Explore database structure in SQLTools sidebar

## Step 7: Development Workflow

1. **Start Development Server**
   ```bash
   python main.py
   ```
   Or use VS Code debugger (F5)

2. **Database Operations**
   - Use SQLTools to run queries
   - Monitor database changes in real-time
   - Use pgAdmin for advanced management

3. **Code Formatting**
   - Install Black: `pip install black`
   - Format code: `black .`
   - Configure auto-formatting on save

## Step 8: Testing Setup

1. **Install Testing Dependencies**
   ```bash
   pip install pytest pytest-flask pytest-cov
   ```

2. **Create tests/ Directory**
   ```bash
   mkdir tests
   touch tests/__init__.py
   touch tests/test_app.py
   ```

3. **Basic Test Configuration**
   ```python
   # tests/test_app.py
   import pytest
   from app import app, db
   
   @pytest.fixture
   def client():
       app.config['TESTING'] = True
       app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
       
       with app.test_client() as client:
           with app.app_context():
               db.create_all()
               yield client
               db.drop_all()
   
   def test_homepage(client):
       response = client.get('/')
       assert response.status_code == 200
   ```

## Step 9: Git Configuration

1. **Create .gitignore**
   ```
   __pycache__/
   *.pyc
   *.pyo
   *.pyd
   .Python
   venv/
   .env
   .vscode/settings.json
   *.db
   uploads/
   .pytest_cache/
   ```

2. **Initial Commit**
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Nikoji Technologies website"
   ```

## Step 10: Debugging Configuration

1. **Enable Flask Debug Mode**
   ```python
   # In app.py
   if __name__ == '__main__':
       app.run(host='0.0.0.0', port=5000, debug=True)
   ```

2. **Use VS Code Debugger**
   - Set breakpoints by clicking line numbers
   - Press F5 to start debugging
   - Use debug console for interactive debugging

3. **Database Query Debugging**
   ```python
   # Add to app.py for query logging
   import logging
   logging.basicConfig(level=logging.DEBUG)
   app.config['SQLALCHEMY_ECHO'] = True
   ```

## Development Best Practices

1. **Code Organization**
   - Keep routes in separate files by functionality
   - Use blueprints for modular design
   - Follow PEP 8 style guidelines

2. **Database Management**
   - Use migrations for schema changes
   - Backup database before major changes
   - Test queries in SQLTools before implementation

3. **Error Handling**
   - Implement proper exception handling
   - Log errors for debugging
   - Use Flask's error handlers

4. **Security**
   - Never commit sensitive data
   - Use environment variables for secrets
   - Validate all user inputs

## Useful VS Code Shortcuts

- `Ctrl+Shift+P`: Command Palette
- `Ctrl+`` `: Toggle Terminal
- `F5`: Start Debugging
- `Ctrl+Shift+F`: Search in Files
- `Ctrl+B`: Toggle Sidebar
- `Alt+Shift+F`: Format Document

## Troubleshooting

1. **Import Errors**
   - Check virtual environment activation
   - Verify Python interpreter path
   - Ensure all dependencies installed

2. **Database Connection Issues**
   - Verify PostgreSQL service running
   - Check connection credentials
   - Test connection in SQLTools

3. **Flask App Not Starting**
   - Check for syntax errors
   - Verify environment variables
   - Check port availability

4. **Static Files Not Loading**
   - Verify file paths in templates
   - Check Flask static folder configuration
   - Clear browser cache

## Performance Monitoring

1. **Flask-SQLAlchemy Query Monitoring**
   ```python
   from flask_sqlalchemy import get_debug_queries
   
   @app.after_request
   def after_request(response):
       for query in get_debug_queries():
           if query.duration >= 0.01:  # Log slow queries
               app.logger.warning(f"Slow query: {query.statement}")
       return response
   ```

2. **Memory Usage Monitoring**
   ```bash
   pip install memory-profiler
   python -m memory_profiler main.py
   ```

This setup provides a complete development environment for the Nikoji Technologies website with PostgreSQL integration and comprehensive tooling support.