# cPanel Database Setup Guide for Nikoji Technologies

## Step 1: Create PostgreSQL Database in cPanel

1. **Login to cPanel**
   - Access your hosting provider's cPanel interface
   - Navigate to the "Databases" section

2. **Create PostgreSQL Database**
   - Click on "PostgreSQL Databases"
   - Create a new database named: `nikoji_tech_db`
   - Note down the database name (usually prefixed with your username)

3. **Create Database User**
   - Create a new user with a strong password
   - Grant ALL PRIVILEGES to the user for the database
   - Note down the username and password

4. **Get Connection Details**
   ```
   Host: localhost (or your server's hostname)
   Port: 5432 (default PostgreSQL port)
   Database: your_username_nikoji_tech_db
   Username: your_username_dbuser
   Password: your_chosen_password
   ```

## Step 2: Execute Database Schema

1. **Access phpPgAdmin or PostgreSQL Command Line**
   - Most cPanel installations include phpPgAdmin
   - Navigate to phpPgAdmin in cPanel

2. **Run the Setup Script**
   - Copy and paste the contents of `cpanel_database_setup.sql`
   - Execute the script to create all tables and indexes

3. **Verify Table Creation**
   ```sql
   SELECT table_name FROM information_schema.tables 
   WHERE table_schema = 'public';
   ```

## Step 3: Configure Environment Variables

1. **Set Environment Variables in cPanel**
   - Go to "Software" section
   - Click on "Python App" or "Node.js App" (depending on your setup)
   - Add these environment variables:

   ```
   DATABASE_URL=postgresql://username:password@localhost:5432/database_name
   PGHOST=localhost
   PGPORT=5432
   PGDATABASE=your_username_nikoji_tech_db
   PGUSER=your_username_dbuser
   PGPASSWORD=your_password
   SESSION_SECRET=your_random_secret_key_here
   ```

2. **Alternative: Use .env File**
   - Create `.env` file in your application root
   - Add the same environment variables as above
   - Ensure the file is not publicly accessible

## Step 4: Upload Application Files

1. **File Upload via File Manager**
   - Use cPanel File Manager to upload your application
   - Extract files to your domain's public folder
   - Ensure proper file permissions (644 for files, 755 for directories)

2. **Required Directory Structure**
   ```
   public_html/
   ├── app.py
   ├── main.py
   ├── routes.py
   ├── models.py
   ├── forms.py
   ├── admin.py
   ├── requirements.txt
   ├── static/
   ├── templates/
   └── uploads/ (create this directory)
   ```

## Step 5: Install Python Dependencies

1. **Using cPanel Python App Manager**
   - Navigate to "Python App" in cPanel
   - Create a new Python application
   - Upload and install from `requirements.txt`

2. **Manual Installation (if SSH access available)**
   ```bash
   pip install -r requirements.txt
   ```

## Step 6: Configure Web Application

1. **Set Startup File**
   - In Python App settings, set startup file to `main.py`
   - Set application root to your domain folder

2. **Configure WSGI**
   - Ensure WSGI configuration points to your Flask app
   - The main application object should be named `app`

## Step 7: Test Database Connection

1. **Run Connection Test**
   ```python
   import os
   import psycopg2
   
   try:
       conn = psycopg2.connect(
           host=os.environ.get('PGHOST'),
           port=os.environ.get('PGPORT'),
           database=os.environ.get('PGDATABASE'),
           user=os.environ.get('PGUSER'),
           password=os.environ.get('PGPASSWORD')
       )
       print("Database connection successful!")
       conn.close()
   except Exception as e:
       print(f"Connection failed: {e}")
   ```

## Step 8: Create Upload Directory

1. **Create Uploads Folder**
   ```bash
   mkdir static/uploads
   chmod 755 static/uploads
   ```

2. **Set Proper Permissions**
   - Ensure the web server can write to the uploads directory
   - Set appropriate permissions for security

## Common Issues and Solutions

### Issue 1: Database Connection Failed
**Solution:**
- Verify database credentials are correct
- Check if PostgreSQL service is running
- Ensure firewall allows connections on port 5432

### Issue 2: Permission Denied
**Solution:**
- Check file and directory permissions
- Ensure web server user has access to application files
- Verify database user has required privileges

### Issue 3: Module Import Errors
**Solution:**
- Verify all dependencies are installed
- Check Python version compatibility
- Ensure all files are in correct directories

### Issue 4: File Upload Issues
**Solution:**
- Create uploads directory with write permissions
- Check available disk space
- Verify file size limits in hosting configuration

## Security Recommendations

1. **Database Security**
   - Use strong passwords for database users
   - Limit database user privileges to minimum required
   - Regularly backup database

2. **File Security**
   - Validate file types before upload
   - Scan uploaded files for malware
   - Set file size limits

3. **Application Security**
   - Keep secret keys secure and random
   - Use HTTPS for production
   - Regularly update dependencies

## Backup Strategy

1. **Database Backup**
   ```bash
   pg_dump -h hostname -U username database_name > backup.sql
   ```

2. **File Backup**
   - Regular backups of application files
   - Include uploaded files in backup strategy
   - Test restore procedures

## Monitoring and Maintenance

1. **Log Files**
   - Monitor application logs for errors
   - Check database logs for performance issues
   - Set up log rotation

2. **Performance Monitoring**
   - Monitor database query performance
   - Check application response times
   - Monitor disk space usage

3. **Regular Updates**
   - Keep Python packages updated
   - Apply security patches promptly
   - Monitor for dependency vulnerabilities