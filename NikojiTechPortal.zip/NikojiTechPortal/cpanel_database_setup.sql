-- cPanel PostgreSQL Database Setup for Nikoji Technologies
-- Run these commands in cPanel phpPgAdmin or PostgreSQL command line

-- Create database (if not already created through cPanel interface)
-- CREATE DATABASE nikoji_tech_db;

-- Connect to the database
-- \c nikoji_tech_db;

-- Create contact submissions table
CREATE TABLE IF NOT EXISTS contact_submissions (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL,
    company VARCHAR(100),
    service VARCHAR(50),
    message TEXT NOT NULL,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'new' CHECK (status IN ('new', 'contacted', 'resolved'))
);

-- Create newsletter subscribers table
CREATE TABLE IF NOT EXISTS newsletter_subscribers (
    id SERIAL PRIMARY KEY,
    email VARCHAR(120) UNIQUE NOT NULL,
    subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

-- Create projects table
CREATE TABLE IF NOT EXISTS projects (
    id SERIAL PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    category VARCHAR(50) NOT NULL CHECK (category IN ('automation', 'software', 'design', 'ems')),
    technologies VARCHAR(500),
    client_name VARCHAR(100),
    project_date DATE,
    status VARCHAR(20) DEFAULT 'completed' CHECK (status IN ('completed', 'ongoing', 'planned')),
    featured BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create service inquiries table
CREATE TABLE IF NOT EXISTS service_inquiries (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL,
    company VARCHAR(100),
    service_type VARCHAR(50) NOT NULL,
    project_scope TEXT,
    budget_range VARCHAR(50),
    timeline VARCHAR(50),
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'new' CHECK (status IN ('new', 'contacted', 'resolved'))
);

-- Create testimonials table
CREATE TABLE IF NOT EXISTS testimonials (
    id SERIAL PRIMARY KEY,
    client_name VARCHAR(100) NOT NULL,
    company VARCHAR(100) NOT NULL,
    position VARCHAR(100),
    testimonial_text TEXT NOT NULL,
    rating INTEGER CHECK (rating >= 1 AND rating <= 5),
    project_type VARCHAR(50),
    is_featured BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create file uploads table for admin panel
CREATE TABLE IF NOT EXISTS file_uploads (
    id SERIAL PRIMARY KEY,
    filename VARCHAR(255) NOT NULL,
    original_filename VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_type VARCHAR(100) NOT NULL,
    file_size INTEGER NOT NULL,
    uploaded_by VARCHAR(100),
    upload_type VARCHAR(50) NOT NULL CHECK (upload_type IN ('brochure', 'project_image', 'testimonial_image', 'general')),
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_contact_submissions_email ON contact_submissions(email);
CREATE INDEX IF NOT EXISTS idx_contact_submissions_status ON contact_submissions(status);
CREATE INDEX IF NOT EXISTS idx_contact_submissions_submitted_at ON contact_submissions(submitted_at);

CREATE INDEX IF NOT EXISTS idx_newsletter_subscribers_email ON newsletter_subscribers(email);
CREATE INDEX IF NOT EXISTS idx_newsletter_subscribers_active ON newsletter_subscribers(is_active);

CREATE INDEX IF NOT EXISTS idx_projects_category ON projects(category);
CREATE INDEX IF NOT EXISTS idx_projects_featured ON projects(featured);
CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);

CREATE INDEX IF NOT EXISTS idx_service_inquiries_email ON service_inquiries(email);
CREATE INDEX IF NOT EXISTS idx_service_inquiries_status ON service_inquiries(status);

CREATE INDEX IF NOT EXISTS idx_testimonials_featured ON testimonials(is_featured);
CREATE INDEX IF NOT EXISTS idx_testimonials_rating ON testimonials(rating);

CREATE INDEX IF NOT EXISTS idx_file_uploads_type ON file_uploads(upload_type);
CREATE INDEX IF NOT EXISTS idx_file_uploads_active ON file_uploads(is_active);

-- Insert sample data for testing (optional)
INSERT INTO projects (title, description, category, technologies, client_name, featured) VALUES
('Industrial Automation System', 'Complete automation solution for manufacturing plant', 'automation', 'PLC, SCADA, HMI', 'ABC Manufacturing', true),
('EMS Quality Control', 'Electronic manufacturing services quality management system', 'ems', 'Python, PostgreSQL, React', 'Tech Electronics', true),
('Custom Software Solution', 'Tailored software for inventory management', 'software', 'Flask, PostgreSQL, Bootstrap', 'Retail Corp', false);

INSERT INTO testimonials (client_name, company, position, testimonial_text, rating, project_type, is_featured) VALUES
('John Smith', 'ABC Manufacturing', 'Plant Manager', 'Nikoji Technologies delivered an exceptional automation solution that increased our productivity by 40%.', 5, 'automation', true),
('Sarah Johnson', 'Tech Electronics', 'Quality Director', 'Their EMS solutions have transformed our quality control processes completely.', 5, 'ems', true);

-- Grant necessary permissions (adjust username as needed)
-- GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO your_username;
-- GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO your_username;

-- View all tables
SELECT table_name, table_type 
FROM information_schema.tables 
WHERE table_schema = 'public' 
ORDER BY table_name;

-- Check table structures
SELECT table_name, column_name, data_type, is_nullable, column_default
FROM information_schema.columns 
WHERE table_schema = 'public' 
ORDER BY table_name, ordinal_position;