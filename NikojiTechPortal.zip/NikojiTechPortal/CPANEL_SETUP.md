# cPanel Deployment Guide for Nikoji Technologies Website

This guide provides step-by-step instructions for deploying the Nikoji Technologies Flask website to a cPanel hosting environment.

## Prerequisites

- cPanel hosting account with Python support
- Access to cPanel File Manager or FTP
- Domain name configured
- Basic understanding of cPanel interface

## Step 1: Prepare Your Files

1. **Download/Export Project Files**
   - Download all project files from your development environment
   - Ensure you have all folders: `templates/`, `static/`, Python files

2. **Required Files Checklist**
   ```
   ├── main.py
   ├── app.py
   ├── routes.py
   ├── forms.py
   ├── requirements.txt (create if missing)
   ├── templates/
   │   ├── base.html
   │   ├── index.html
   │   ├── about.html
   │   ├── projects.html
   │   ├── contact.html
   │   ├── privacy-policy.html
   │   ├── terms-of-service.html
   │   ├── 404.html
   │   ├── 500.html
   │   └── [service pages]
   └── static/
       ├── css/
       ├── js/
       └── images/
   ```

## Step 2: Create requirements.txt

Create a `requirements.txt` file with the following content:

```txt
Flask==2.3.3
Flask-SQLAlchemy==3.0.5
Flask-WTF==1.1.1
WTForms==3.0.1
email-validator==2.0.0
gunicorn==21.2.0
psycopg2-binary==2.9.7
```

## Step 3: cPanel Setup

### 3.1 Access cPanel
1. Log into your hosting provider's control panel
2. Navigate to cPanel
3. Look for "Python Apps" or "Setup Python App"

### 3.2 Create Python Application
1. Click "Create Application"
2. Select Python version (3.8 or higher recommended)
3. Set Application root: `public_html/nikoji-app` (or your preferred folder)
4. Set Application URL: your domain or subdomain
5. Set Application startup file: `main.py`
6. Click "Create"

### 3.3 Configure Environment Variables
1. In the Python App settings, find "Environment Variables"
2. Add the following variables:
   ```
   SESSION_SECRET=your-secret-key-here
   DATABASE_URL=sqlite:///site.db
   FLASK_ENV=production
   ```

## Step 4: Upload Files

### Method 1: File Manager
1. In cPanel, open "File Manager"
2. Navigate to your application root folder
3. Upload all project files maintaining folder structure
4. Extract if uploaded as ZIP

### Method 2: FTP
1. Use FTP client (FileZilla, WinSCP, etc.)
2. Connect using your cPanel FTP credentials
3. Upload files to application root directory

## Step 5: Install Dependencies

1. In cPanel Python App, click "Open Terminal" or use SSH
2. Navigate to your application directory:
   ```bash
   cd public_html/nikoji-app
   ```
3. Install requirements:
   ```bash
   pip install -r requirements.txt
   ```

## Step 6: Database Setup

### For SQLite (Recommended for small sites)
1. Ensure `DATABASE_URL` points to SQLite file
2. The database will be created automatically

### For MySQL (if needed)
1. Create MySQL database in cPanel
2. Update `DATABASE_URL` environment variable:
   ```
   mysql://username:password@localhost/database_name
   ```

## Step 7: Configure Application

1. **Update main.py for production:**
   ```python
   from app import app
   
   if __name__ == '__main__':
       app.run(debug=False, host='0.0.0.0', port=5000)
   ```

2. **Verify app.py configuration:**
   ```python
   import os
   from flask import Flask
   
   app = Flask(__name__)
   app.secret_key = os.environ.get("SESSION_SECRET", "fallback-secret-key")
   
   # Import routes
   from routes import *
   ```

## Step 8: Domain Configuration

1. **Main Domain:** 
   - Point application URL to your main domain
   - Update DNS if necessary

2. **Subdomain:**
   - Create subdomain in cPanel
   - Point to application directory

## Step 9: SSL Certificate

1. In cPanel, find "SSL/TLS"
2. Install SSL certificate (Let's Encrypt is often free)
3. Force HTTPS redirects

## Step 10: Test Deployment

1. Visit your domain
2. Test all pages and functionality
3. Check contact forms
4. Verify navigation

## Troubleshooting

### Common Issues:

1. **Application won't start:**
   - Check Python version compatibility
   - Verify all dependencies installed
   - Check error logs in cPanel

2. **Static files not loading:**
   - Verify folder structure
   - Check file permissions (755 for folders, 644 for files)
   - Ensure static folder is in correct location

3. **Database errors:**
   - Check DATABASE_URL environment variable
   - Verify database permissions
   - Check if database file exists (SQLite)

4. **Import errors:**
   - Ensure all Python files are uploaded
   - Check for case-sensitive filename issues
   - Verify requirements.txt is complete

### Log Files:
- Check application logs in cPanel Python App section
- Review error logs for detailed error messages

## Maintenance

### Regular Updates:
1. Backup database and files regularly
2. Update dependencies periodically
3. Monitor application performance
4. Check error logs regularly

### Security:
1. Keep Python and dependencies updated
2. Use strong SESSION_SECRET
3. Enable HTTPS
4. Regular security backups

## Support

For hosting-specific issues:
- Contact your hosting provider's support
- Check hosting provider's Python/Flask documentation
- Verify cPanel Python version compatibility

For application issues:
- Check Flask documentation
- Review application error logs
- Test locally first before deploying

## Performance Optimization

1. **Enable Gzip compression** in cPanel
2. **Configure caching** for static files
3. **Optimize images** in static/images/
4. **Monitor resource usage** in cPanel metrics

---

**Note:** This guide assumes standard cPanel hosting. Some hosting providers may have different interfaces or requirements. Always consult your hosting provider's documentation for specific instructions.