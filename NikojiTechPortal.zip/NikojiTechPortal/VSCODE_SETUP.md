# VS Code Development Setup for Nikoji Technologies Website

This guide provides comprehensive instructions for setting up Visual Studio Code for developing and maintaining the Nikoji Technologies Flask website.

## Prerequisites

- Visual Studio Code installed
- Python 3.8 or higher
- Git (optional but recommended)

## Step 1: Install Required Extensions

### Essential Extensions:

1. **Python** (Microsoft)
   - Provides Python language support
   - IntelliSense, debugging, and code navigation

2. **Flask Snippets** (cstrap)
   - Flask-specific code snippets
   - Template shortcuts

3. **Jinja** (wholroyd)
   - Syntax highlighting for Jinja2 templates
   - Auto-completion for template tags

4. **HTML CSS Support** (ecmel)
   - Enhanced HTML and CSS IntelliSense
   - Auto-completion for CSS classes

5. **Bootstrap 5 Quick Snippets** (AnbuselvanRocky)
   - Bootstrap component snippets
   - Quick class references

### Recommended Extensions:

6. **Prettier - Code formatter**
   - Auto-format HTML, CSS, and JavaScript
   - Consistent code styling

7. **Live Server** (Ritwick Dey)
   - Local development server for static files
   - Auto-reload on changes

8. **GitLens** (GitKraken)
   - Enhanced Git capabilities
   - Inline blame and history

9. **Auto Rename Tag** (Jun Han)
   - Automatically rename paired HTML tags

10. **Bracket Pair Colorizer 2** (CoenraadS)
    - Color-code matching brackets
    - Improved code readability

## Step 2: Workspace Configuration

### Create .vscode/settings.json:

```json
{
    "python.defaultInterpreterPath": "./venv/bin/python",
    "python.terminal.activateEnvironment": true,
    "python.linting.enabled": true,
    "python.linting.pylintEnabled": true,
    "python.formatting.provider": "black",
    "files.associations": {
        "*.html": "html",
        "*.jinja": "jinja-html",
        "*.jinja2": "jinja-html"
    },
    "emmet.includeLanguages": {
        "jinja-html": "html"
    },
    "html.suggest.html5": true,
    "css.validate": true,
    "javascript.validate.enable": true,
    "files.autoSave": "onDelay",
    "files.autoSaveDelay": 1000,
    "editor.formatOnSave": true,
    "editor.tabSize": 4,
    "editor.insertSpaces": true
}
```

### Create .vscode/launch.json for debugging:

```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Flask Development Server",
            "type": "python",
            "request": "launch",
            "program": "${workspaceFolder}/main.py",
            "env": {
                "FLASK_ENV": "development",
                "FLASK_DEBUG": "1",
                "SESSION_SECRET": "dev-secret-key",
                "DATABASE_URL": "sqlite:///site.db"
            },
            "args": [],
            "jinja": true,
            "console": "integratedTerminal"
        }
    ]
}
```

### Create .vscode/tasks.json for common tasks:

```json
{
    "version": "2.0.0",
    "tasks": [
        {
            "label": "Install Dependencies",
            "type": "shell",
            "command": "pip",
            "args": ["install", "-r", "requirements.txt"],
            "group": "build",
            "presentation": {
                "echo": true,
                "reveal": "always",
                "focus": false,
                "panel": "shared"
            }
        },
        {
            "label": "Run Flask App",
            "type": "shell",
            "command": "python",
            "args": ["main.py"],
            "group": {
                "kind": "build",
                "isDefault": true
            },
            "presentation": {
                "echo": true,
                "reveal": "always",
                "focus": false,
                "panel": "shared"
            }
        },
        {
            "label": "Run Tests",
            "type": "shell",
            "command": "python",
            "args": ["-m", "pytest"],
            "group": "test",
            "presentation": {
                "echo": true,
                "reveal": "always",
                "focus": false,
                "panel": "shared"
            }
        }
    ]
}
```

## Step 3: Python Environment Setup

### Create Virtual Environment:

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS/Linux
python3 -m venv venv
source venv/bin/activate
```

### Install Dependencies:

```bash
pip install -r requirements.txt
```

### Environment Variables:

Create `.env` file (add to .gitignore):

```env
SESSION_SECRET=your-development-secret-key
DATABASE_URL=sqlite:///site.db
FLASK_ENV=development
FLASK_DEBUG=1
```

## Step 4: Project Structure Setup

### Recommended Folder Structure:

```
nikoji-technologies/
├── .vscode/
│   ├── settings.json
│   ├── launch.json
│   └── tasks.json
├── static/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── main.js
│   └── images/
│       └── logo.svg
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── about.html
│   ├── projects.html
│   ├── contact.html
│   ├── privacy-policy.html
│   ├── terms-of-service.html
│   ├── 404.html
│   ├── 500.html
│   └── [service pages]
├── app.py
├── main.py
├── routes.py
├── forms.py
├── requirements.txt
├── .env
├── .gitignore
├── README.md
├── CPANEL_SETUP.md
└── VSCODE_SETUP.md
```

## Step 5: Code Snippets

### Create Custom Snippets:

Go to File > Preferences > Configure User Snippets > python.json

```json
{
    "Flask Route": {
        "prefix": "froute",
        "body": [
            "@app.route('/$1')",
            "def $2():",
            "    \"\"\"$3\"\"\"",
            "    return render_template('$4')",
            ""
        ],
        "description": "Flask route template"
    },
    "Flask Form Route": {
        "prefix": "fformroute",
        "body": [
            "@app.route('/$1', methods=['GET', 'POST'])",
            "def $2():",
            "    \"\"\"$3\"\"\"",
            "    form = $4()",
            "    if form.validate_on_submit():",
            "        # Handle form submission",
            "        $5",
            "        return redirect(url_for('$6'))",
            "    return render_template('$7', form=form)",
            ""
        ],
        "description": "Flask form route template"
    }
}
```

### HTML Snippets (html.json):

```json
{
    "Bootstrap Card": {
        "prefix": "bcard",
        "body": [
            "<div class=\"card\">",
            "    <div class=\"card-body\">",
            "        <h5 class=\"card-title\">$1</h5>",
            "        <p class=\"card-text\">$2</p>",
            "        $3",
            "    </div>",
            "</div>"
        ],
        "description": "Bootstrap card component"
    },
    "Flask Block": {
        "prefix": "fblock",
        "body": [
            "{% block $1 %}",
            "$2",
            "{% endblock %}"
        ],
        "description": "Flask template block"
    }
}
```

## Step 6: Debugging Setup

### Debug Configuration:

1. Set breakpoints by clicking in the gutter
2. Press F5 to start debugging
3. Use Debug Console for interactive debugging
4. Monitor variables in the Variables panel

### Common Debug Scenarios:

- **Route Issues:** Set breakpoints in route functions
- **Template Errors:** Check Jinja2 syntax highlighting
- **Form Validation:** Debug form.validate_on_submit()
- **Database Issues:** Monitor SQL queries in debug output

## Step 7: Testing Setup

### Install Testing Dependencies:

```bash
pip install pytest pytest-flask
```

### Create test_app.py:

```python
import pytest
from app import app

@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

def test_homepage(client):
    rv = client.get('/')
    assert rv.status_code == 200
    assert b'Nikoji Technologies' in rv.data

def test_contact_page(client):
    rv = client.get('/contact')
    assert rv.status_code == 200
```

## Step 8: Git Integration

### Create .gitignore:

```gitignore
# Virtual Environment
venv/
env/

# Environment Variables
.env

# Python Cache
__pycache__/
*.pyc
*.pyo
*.pyd

# Database
*.db
*.sqlite

# IDE
.vscode/settings.json (if contains sensitive data)

# OS
.DS_Store
Thumbs.db

# Logs
*.log
```

### Git Commands in VS Code:

- Use Source Control panel (Ctrl+Shift+G)
- Stage files with + icon
- Commit with Ctrl+Enter
- Push/Pull using GitLens

## Step 9: Productivity Tips

### Keyboard Shortcuts:

- `Ctrl+Shift+P`: Command Palette
- `Ctrl+\``: Split Editor
- `Ctrl+B`: Toggle Sidebar
- `F12`: Go to Definition
- `Alt+Shift+F`: Format Document
- `Ctrl+F5`: Run Without Debugging

### Multi-cursor Editing:

- `Alt+Click`: Add cursor
- `Ctrl+Alt+Up/Down`: Add cursor above/below
- `Ctrl+D`: Select next occurrence

### File Navigation:

- `Ctrl+P`: Quick Open
- `Ctrl+Shift+E`: Explorer
- `Ctrl+\``: Toggle Terminal

## Step 10: Development Workflow

### Daily Development:

1. **Start Session:**
   ```bash
   source venv/bin/activate  # Activate virtual environment
   code .                    # Open VS Code
   ```

2. **Run Development Server:**
   - Press F5 to start debugging, or
   - Use terminal: `python main.py`

3. **Make Changes:**
   - Edit templates in `templates/`
   - Update styles in `static/css/`
   - Add functionality in Python files

4. **Test Changes:**
   - Use Live Server for static content
   - Refresh browser for Flask changes
   - Run tests with `pytest`

5. **Version Control:**
   - Stage changes in Source Control
   - Write descriptive commit messages
   - Push to repository

### Code Quality:

- Use linting (Pylint) for Python code
- Format code with Black
- Validate HTML and CSS
- Test across different browsers

## Troubleshooting

### Common Issues:

1. **Python Interpreter Not Found:**
   - Check Python extension installation
   - Set correct interpreter path in settings

2. **Import Errors:**
   - Verify virtual environment activation
   - Check PYTHONPATH in settings

3. **Template Syntax Issues:**
   - Install Jinja extension
   - Check file associations in settings

4. **Debugging Not Working:**
   - Verify launch.json configuration
   - Check port availability (5000)

### Performance:

- Disable unused extensions
- Exclude large directories from search
- Use workspace-specific settings

---

**Additional Resources:**

- [Flask Documentation](https://flask.palletsprojects.com/)
- [Bootstrap Documentation](https://getbootstrap.com/docs/)
- [VS Code Python Tutorial](https://code.visualstudio.com/docs/python/python-tutorial)
- [Jinja2 Template Documentation](https://jinja.palletsprojects.com/)