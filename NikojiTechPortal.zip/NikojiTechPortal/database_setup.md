# Database Setup Guide

## PostgreSQL Database Configuration

### Environment Variables
The application uses the following environment variables for database connection:

- `DATABASE_URL`: Complete PostgreSQL connection string
- `PGHOST`: PostgreSQL host
- `PGPORT`: PostgreSQL port (default: 5432)
- `PGDATABASE`: Database name
- `PGUSER`: Database username
- `PGPASSWORD`: Database password

### VS Code Setup

1. **Install PostgreSQL Extension**
   - Install "PostgreSQL" extension by Chris Kolkman
   - Install "SQLTools" extension for database management

2. **Database Connection Configuration**
   ```json
   {
     "sqltools.connections": [
       {
         "name": "Nikoji Technologies DB",
         "driver": "PostgreSQL",
         "server": "${PGHOST}",
         "port": "${PGPORT}",
         "database": "${PGDATABASE}",
         "username": "${PGUSER}",
         "password": "${PGPASSWORD}",
         "connectionTimeout": 30
       }
     ]
   }
   ```

3. **Environment Setup**
   Create `.env` file in project root:
   ```env
   DATABASE_URL=postgresql://username:password@host:port/database
   PGHOST=your_postgres_host
   PGPORT=5432
   PGDATABASE=your_database_name
   PGUSER=your_username
   PGPASSWORD=your_password
   SESSION_SECRET=your_secret_key_here
   ```

### cPanel Setup

1. **Create PostgreSQL Database**
   - Login to cPanel
   - Navigate to "PostgreSQL Databases"
   - Create new database: `nikoji_tech_db`
   - Create database user with full privileges

2. **Database Connection Details**
   ```
   Host: localhost (or your server IP)
   Port: 5432
   Database: nikoji_tech_db
   Username: your_cpanel_username_dbuser
   Password: your_chosen_password
   ```

3. **Update Application Configuration**
   Set environment variables in cPanel:
   ```
   DATABASE_URL=postgresql://username:password@localhost:5432/nikoji_tech_db
   PGHOST=localhost
   PGPORT=5432
   PGDATABASE=nikoji_tech_db
   PGUSER=your_username
   PGPASSWORD=your_password
   ```

## Database Schema

### Tables Created Automatically

1. **contact_submissions**
   ```sql
   CREATE TABLE contact_submissions (
       id SERIAL PRIMARY KEY,
       name VARCHAR(100) NOT NULL,
       email VARCHAR(120) NOT NULL,
       company VARCHAR(100),
       service VARCHAR(50),
       message TEXT NOT NULL,
       submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
       status VARCHAR(20) DEFAULT 'new'
   );
   ```

2. **newsletter_subscribers**
   ```sql
   CREATE TABLE newsletter_subscribers (
       id SERIAL PRIMARY KEY,
       email VARCHAR(120) UNIQUE NOT NULL,
       subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
       is_active BOOLEAN DEFAULT TRUE
   );
   ```

3. **projects**
   ```sql
   CREATE TABLE projects (
       id SERIAL PRIMARY KEY,
       title VARCHAR(200) NOT NULL,
       description TEXT NOT NULL,
       category VARCHAR(50) NOT NULL,
       technologies VARCHAR(500),
       client_name VARCHAR(100),
       project_date DATE,
       status VARCHAR(20) DEFAULT 'completed',
       featured BOOLEAN DEFAULT FALSE,
       created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
   );
   ```

4. **service_inquiries**
   ```sql
   CREATE TABLE service_inquiries (
       id SERIAL PRIMARY KEY,
       name VARCHAR(100) NOT NULL,
       email VARCHAR(120) NOT NULL,
       company VARCHAR(100),
       service_type VARCHAR(50) NOT NULL,
       project_scope TEXT,
       budget_range VARCHAR(50),
       timeline VARCHAR(50),
       submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
       status VARCHAR(20) DEFAULT 'new'
   );
   ```

5. **testimonials**
   ```sql
   CREATE TABLE testimonials (
       id SERIAL PRIMARY KEY,
       client_name VARCHAR(100) NOT NULL,
       company VARCHAR(100) NOT NULL,
       position VARCHAR(100),
       testimonial_text TEXT NOT NULL,
       rating INTEGER,
       project_type VARCHAR(50),
       is_featured BOOLEAN DEFAULT FALSE,
       created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
   );
   ```

## Manual Database Setup (if needed)

If automatic table creation fails, run these commands:

```sql
-- Create database
CREATE DATABASE nikoji_tech_db;

-- Use the database
\c nikoji_tech_db;

-- Create tables (run each CREATE TABLE statement above)

-- Create indexes for better performance
CREATE INDEX idx_contact_submissions_email ON contact_submissions(email);
CREATE INDEX idx_contact_submissions_status ON contact_submissions(status);
CREATE INDEX idx_newsletter_subscribers_email ON newsletter_subscribers(email);
CREATE INDEX idx_projects_category ON projects(category);
CREATE INDEX idx_projects_featured ON projects(featured);
```

## Testing Database Connection

1. **Python Test Script**
   ```python
   import os
   import psycopg2
   
   try:
       conn = psycopg2.connect(os.environ.get('DATABASE_URL'))
       cursor = conn.cursor()
       cursor.execute("SELECT version();")
       print("Database connection successful!")
       print(cursor.fetchone())
       conn.close()
   except Exception as e:
       print(f"Database connection failed: {e}")
   ```

2. **SQL Test Query**
   ```sql
   SELECT table_name FROM information_schema.tables 
   WHERE table_schema = 'public';
   ```

## Backup and Maintenance

1. **Backup Command**
   ```bash
   pg_dump -h hostname -U username -d database_name > backup.sql
   ```

2. **Restore Command**
   ```bash
   psql -h hostname -U username -d database_name < backup.sql
   ```

## Troubleshooting

1. **Connection Issues**
   - Verify environment variables are set correctly
   - Check PostgreSQL service is running
   - Confirm firewall settings allow connection on port 5432

2. **Permission Issues**
   - Ensure database user has required privileges
   - Check table ownership and permissions

3. **Performance Issues**
   - Add indexes on frequently queried columns
   - Monitor query execution times
   - Consider connection pooling for high traffic