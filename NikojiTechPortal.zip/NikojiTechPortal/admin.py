from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify, send_from_directory
from werkzeug.utils import secure_filename
from app import db, app
from models import ContactSubmission, NewsletterSubscriber, Project, ServiceInquiry, Testimonial, FileUpload
from datetime import datetime, timedelta
from sqlalchemy import func
import os
import uuid

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.route('/')
def dashboard():
    """Admin dashboard with statistics"""
    # Get statistics
    total_contacts = ContactSubmission.query.count()
    total_subscribers = NewsletterSubscriber.query.filter_by(is_active=True).count()
    total_projects = Project.query.count()
    total_inquiries = ServiceInquiry.query.count()
    
    # Recent submissions (last 7 days)
    week_ago = datetime.utcnow() - timedelta(days=7)
    recent_contacts = ContactSubmission.query.filter(
        ContactSubmission.submitted_at >= week_ago
    ).count()
    
    recent_subscribers = NewsletterSubscriber.query.filter(
        NewsletterSubscriber.subscribed_at >= week_ago
    ).count()
    
    # Latest submissions
    latest_contacts = ContactSubmission.query.order_by(
        ContactSubmission.submitted_at.desc()
    ).limit(5).all()
    
    latest_subscribers = NewsletterSubscriber.query.order_by(
        NewsletterSubscriber.subscribed_at.desc()
    ).limit(5).all()
    
    return render_template('admin/dashboard.html',
                         total_contacts=total_contacts,
                         total_subscribers=total_subscribers,
                         total_projects=total_projects,
                         total_inquiries=total_inquiries,
                         recent_contacts=recent_contacts,
                         recent_subscribers=recent_subscribers,
                         latest_contacts=latest_contacts,
                         latest_subscribers=latest_subscribers)

@admin_bp.route('/contacts')
def contacts():
    """Manage contact submissions"""
    page = request.args.get('page', 1, type=int)
    status_filter = request.args.get('status', 'all')
    
    query = ContactSubmission.query
    if status_filter != 'all':
        query = query.filter_by(status=status_filter)
    
    contacts = query.order_by(ContactSubmission.submitted_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('admin/contacts.html', contacts=contacts, status_filter=status_filter)

@admin_bp.route('/contacts/<int:contact_id>/update-status', methods=['POST'])
def update_contact_status(contact_id):
    """Update contact submission status"""
    contact = ContactSubmission.query.get_or_404(contact_id)
    new_status = request.form.get('status')
    
    if new_status in ['new', 'contacted', 'resolved']:
        contact.status = new_status
        db.session.commit()
        flash(f'Contact status updated to {new_status}', 'success')
    else:
        flash('Invalid status', 'error')
    
    return redirect(url_for('admin.contacts'))

@admin_bp.route('/newsletters')
def newsletters():
    """Manage newsletter subscribers"""
    page = request.args.get('page', 1, type=int)
    active_filter = request.args.get('active', 'all')
    
    query = NewsletterSubscriber.query
    if active_filter == 'active':
        query = query.filter_by(is_active=True)
    elif active_filter == 'inactive':
        query = query.filter_by(is_active=False)
    
    subscribers = query.order_by(NewsletterSubscriber.subscribed_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('admin/newsletters.html', subscribers=subscribers, active_filter=active_filter)

@admin_bp.route('/newsletters/<int:subscriber_id>/toggle', methods=['POST'])
def toggle_subscriber(subscriber_id):
    """Toggle newsletter subscriber status"""
    subscriber = NewsletterSubscriber.query.get_or_404(subscriber_id)
    subscriber.is_active = not subscriber.is_active
    db.session.commit()
    
    status = 'activated' if subscriber.is_active else 'deactivated'
    flash(f'Subscriber {status}', 'success')
    
    return redirect(url_for('admin.newsletters'))

@admin_bp.route('/api/stats')
def api_stats():
    """API endpoint for dashboard statistics"""
    # Monthly contact submissions for the last 6 months
    months_data = []
    for i in range(6):
        start_date = datetime.utcnow().replace(day=1) - timedelta(days=30*i)
        end_date = start_date.replace(month=start_date.month+1) if start_date.month < 12 else start_date.replace(year=start_date.year+1, month=1)
        
        count = ContactSubmission.query.filter(
            ContactSubmission.submitted_at >= start_date,
            ContactSubmission.submitted_at < end_date
        ).count()
        
        months_data.append({
            'month': start_date.strftime('%b %Y'),
            'contacts': count
        })
    
    # Service interest distribution
    service_stats = db.session.query(
        ContactSubmission.service,
        func.count(ContactSubmission.id).label('count')
    ).filter(
        ContactSubmission.service.isnot(None)
    ).group_by(ContactSubmission.service).all()
    
    return jsonify({
        'monthly_contacts': list(reversed(months_data)),
        'service_distribution': [{'service': s[0], 'count': s[1]} for s in service_stats]
    })

# File upload configuration
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 'txt'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@admin_bp.route('/files')
def files():
    """Manage uploaded files"""
    page = request.args.get('page', 1, type=int)
    file_type = request.args.get('type', 'all')
    
    query = FileUpload.query.filter_by(is_active=True)
    if file_type != 'all':
        query = query.filter_by(upload_type=file_type)
    
    files = query.order_by(FileUpload.uploaded_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('admin/files.html', files=files, file_type=file_type)

@admin_bp.route('/upload', methods=['GET', 'POST'])
def upload_file():
    """Upload new file"""
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file selected', 'error')
            return redirect(request.url)
        
        file = request.files['file']
        upload_type = request.form.get('upload_type', 'general')
        
        if file.filename == '':
            flash('No file selected', 'error')
            return redirect(request.url)
        
        if file and allowed_file(file.filename):
            # Create upload directory if it doesn't exist
            os.makedirs(UPLOAD_FOLDER, exist_ok=True)
            
            # Generate unique filename
            filename = secure_filename(file.filename)
            unique_filename = f"{uuid.uuid4()}_{filename}"
            file_path = os.path.join(UPLOAD_FOLDER, unique_filename)
            
            try:
                file.save(file_path)
                
                # Save file info to database
                file_upload = FileUpload(
                    filename=unique_filename,
                    original_filename=filename,
                    file_path=file_path,
                    file_type=file.content_type or 'application/octet-stream',
                    file_size=os.path.getsize(file_path),
                    upload_type=upload_type
                )
                
                db.session.add(file_upload)
                db.session.commit()
                
                flash(f'File "{filename}" uploaded successfully!', 'success')
                return redirect(url_for('admin.files'))
                
            except Exception as e:
                flash(f'Error uploading file: {str(e)}', 'error')
                return redirect(request.url)
        else:
            flash('Invalid file type. Allowed types: PDF, PNG, JPG, JPEG, GIF, DOC, DOCX, TXT', 'error')
    
    return render_template('admin/upload.html')

@admin_bp.route('/files/<int:file_id>/download')
def download_file(file_id):
    """Download file"""
    file_upload = FileUpload.query.get_or_404(file_id)
    
    try:
        directory = os.path.dirname(file_upload.file_path)
        filename = os.path.basename(file_upload.file_path)
        return send_from_directory(directory, filename, as_attachment=True, 
                                 download_name=file_upload.original_filename)
    except Exception as e:
        flash(f'Error downloading file: {str(e)}', 'error')
        return redirect(url_for('admin.files'))

@admin_bp.route('/files/<int:file_id>/delete', methods=['POST'])
def delete_file(file_id):
    """Delete file"""
    file_upload = FileUpload.query.get_or_404(file_id)
    
    try:
        # Remove physical file
        if os.path.exists(file_upload.file_path):
            os.remove(file_upload.file_path)
        
        # Mark as inactive in database
        file_upload.is_active = False
        db.session.commit()
        
        flash('File deleted successfully', 'success')
    except Exception as e:
        flash(f'Error deleting file: {str(e)}', 'error')
    
    return redirect(url_for('admin.files'))

@admin_bp.route('/quick-contact')
def quick_contact():
    """Quick contact management"""
    recent_contacts = ContactSubmission.query.filter_by(status='new').order_by(
        ContactSubmission.submitted_at.desc()
    ).limit(10).all()
    
    return render_template('admin/quick_contact.html', contacts=recent_contacts)