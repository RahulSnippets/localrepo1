// Main JavaScript for Nikoji Technologies Website

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all interactive components
    initNavigation();
    initHeroAnimations();
    initStatsCounter();
    initProjectFilters();
    initTestimonialCarousel();
    initScrollAnimations();
    initFormValidation();
    initServiceSelector();
    initSmoothScrolling();
});

// Navigation functionality
function initNavigation() {
    const navbar = document.querySelector('.navbar');
    
    // Add scroll effect to navbar
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });
    
    // Mobile menu toggle
    const navbarToggler = document.querySelector('.navbar-toggler');
    const navbarCollapse = document.querySelector('.navbar-collapse');
    
    if (navbarToggler && navbarCollapse) {
        navbarToggler.addEventListener('click', function() {
            navbarCollapse.classList.toggle('show');
        });
    }
    
    // Close mobile menu when clicking on a link
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth < 992) {
                navbarCollapse.classList.remove('show');
            }
        });
    });
}

// Hero section animations
function initHeroAnimations() {
    const heroSection = document.querySelector('.hero-section');
    if (!heroSection) return;
    
    // Parallax effect for hero background
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const heroBackground = document.querySelector('.hero-background');
        if (heroBackground) {
            heroBackground.style.transform = `translateY(${scrolled * 0.5}px)`;
        }
    });
    
    // Animate hero content on load
    const heroContent = heroSection.querySelector('.col-lg-6');
    if (heroContent) {
        heroContent.classList.add('fade-in-up');
    }
}

// Statistics counter animation
function initStatsCounter() {
    const statNumbers = document.querySelectorAll('.stat-number');
    
    const animateCounter = (element) => {
        const target = parseInt(element.getAttribute('data-target'));
        const count = parseInt(element.textContent);
        const increment = target / 50;
        
        if (count < target) {
            element.textContent = Math.ceil(count + increment);
            setTimeout(() => animateCounter(element), 40);
        } else {
            element.textContent = target;
        }
    };
    
    // Intersection Observer for stats animation
    const statsObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const statNumber = entry.target.querySelector('.stat-number');
                if (statNumber && !statNumber.classList.contains('animated')) {
                    statNumber.classList.add('animated');
                    animateCounter(statNumber);
                }
            }
        });
    }, { threshold: 0.5 });
    
    document.querySelectorAll('.stat-item').forEach(item => {
        statsObserver.observe(item);
    });
}

// Project filtering functionality
function initProjectFilters() {
    const filterButtons = document.querySelectorAll('.project-filters .btn');
    const projectItems = document.querySelectorAll('.project-item');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            this.classList.add('active');
            
            const filter = this.getAttribute('data-filter');
            
            projectItems.forEach(item => {
                if (filter === 'all' || item.getAttribute('data-category') === filter) {
                    item.style.display = 'block';
                    item.style.animation = 'fadeInUp 0.5s ease-out';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });
}

// Testimonial carousel functionality
function initTestimonialCarousel() {
    const carousel = document.querySelector('#testimonialCarousel');
    if (!carousel) return;
    
    // Auto-play carousel
    const carouselInstance = new bootstrap.Carousel(carousel, {
        interval: 5000,
        ride: 'carousel'
    });
    
    // Pause on hover
    carousel.addEventListener('mouseenter', () => {
        carouselInstance.pause();
    });
    
    carousel.addEventListener('mouseleave', () => {
        carouselInstance.cycle();
    });
}

// Enhanced scroll animations
function initScrollAnimations() {
    // Main animation observer
    const animateOnScroll = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const element = entry.target;
                const animationType = element.getAttribute('data-animation') || 'fade-in-up';
                element.classList.add(animationType);
                
                // Add stagger effect for multiple elements
                const siblings = Array.from(element.parentNode.children);
                const index = siblings.indexOf(element);
                element.style.animationDelay = `${index * 0.1}s`;
            }
        });
    }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });
    
    // Animate service cards with different effects
    document.querySelectorAll('.service-card').forEach((card, index) => {
        const animations = ['fade-in-up', 'fade-in-left', 'fade-in-right', 'scale-in'];
        card.setAttribute('data-animation', animations[index % animations.length]);
        card.classList.add('hover-lift');
        animateOnScroll.observe(card);
    });
    
    // Animate project cards
    document.querySelectorAll('.project-card').forEach(card => {
        card.classList.add('hover-lift');
        card.setAttribute('data-animation', 'bounce-in');
        animateOnScroll.observe(card);
    });
    
    // Animate section headings
    document.querySelectorAll('h1, h2, h3').forEach((heading, index) => {
        heading.setAttribute('data-animation', index % 2 === 0 ? 'slide-in-down' : 'fade-in-up');
        animateOnScroll.observe(heading);
    });
    
    // Animate stats
    document.querySelectorAll('.stat-item').forEach(stat => {
        stat.setAttribute('data-animation', 'bounce-in');
        animateOnScroll.observe(stat);
    });
    
    // Animate buttons and CTAs
    document.querySelectorAll('.btn').forEach(btn => {
        btn.classList.add('hover-scale');
    });
    
    // Add floating animation to icons
    document.querySelectorAll('.service-icon, .competency-icon').forEach(icon => {
        icon.classList.add('floating');
    });
    
    // Add pulse animation to important elements
    document.querySelectorAll('.stat-number').forEach(num => {
        num.classList.add('pulse');
    });
}

// Form validation and enhancement
function initFormValidation() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
        
        // Real-time validation
        const inputs = form.querySelectorAll('input, textarea, select');
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                if (this.checkValidity()) {
                    this.classList.remove('is-invalid');
                    this.classList.add('is-valid');
                } else {
                    this.classList.remove('is-valid');
                    this.classList.add('is-invalid');
                }
            });
            
            input.addEventListener('input', function() {
                if (this.classList.contains('is-invalid') && this.checkValidity()) {
                    this.classList.remove('is-invalid');
                    this.classList.add('is-valid');
                }
            });
        });
    });
    
    // Newsletter form handling
    const newsletterForm = document.querySelector('form[action*="newsletter"]');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(event) {
            const email = this.querySelector('input[type="email"]');
            if (email && email.value) {
                // Show loading state
                const button = this.querySelector('button[type="submit"]');
                const originalText = button.textContent;
                button.textContent = 'Subscribing...';
                button.disabled = true;
                
                // Reset after submission
                setTimeout(() => {
                    button.textContent = originalText;
                    button.disabled = false;
                    email.value = '';
                }, 2000);
            }
        });
    }
}

// Service selector functionality
function initServiceSelector() {
    const goalRadios = document.querySelectorAll('input[name="goal"]');
    const recommendationDiv = document.getElementById('serviceRecommendation');
    const recommendedServiceSpan = document.getElementById('recommendedService');
    
    if (!goalRadios.length || !recommendationDiv || !recommendedServiceSpan) return;
    
    const serviceRecommendations = {
        'goal1': {
            service: 'Automation Services',
            description: 'Our PLC programming and SCADA systems are perfect for automating existing processes.',
            link: '/automation'
        },
        'goal2': {
            service: 'Design & Development',
            description: 'We can help bring your product ideas to life with our comprehensive development services.',
            link: '/design-development'
        },
        'goal3': {
            service: 'EMS Solutions',
            description: 'Our electronics manufacturing services can optimize your production processes.',
            link: '/ems-solutions'
        },
        'goal4': {
            service: 'Consultancy Services',
            description: 'Our strategic guidance will help you navigate complex automation decisions.',
            link: '/consultancy'
        }
    };
    
    goalRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            if (this.checked) {
                const recommendation = serviceRecommendations[this.id];
                recommendedServiceSpan.innerHTML = `
                    <strong>${recommendation.service}</strong><br>
                    ${recommendation.description}<br>
                    <a href="${recommendation.link}" class="btn btn-sm btn-outline-primary mt-2">Learn More</a>
                `;
                recommendationDiv.style.display = 'block';
                recommendationDiv.style.animation = 'fadeInUp 0.5s ease-out';
            }
        });
    });
}

// Smooth scrolling for anchor links
function initSmoothScrolling() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const headerOffset = 80;
                const elementPosition = target.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
                
                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// Utility functions
function debounce(func, wait, immediate) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            timeout = null;
            if (!immediate) func(...args);
        };
        const callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func(...args);
    };
}

// Performance optimization for scroll events
const optimizedScroll = debounce(function() {
    // Any scroll-based animations go here
}, 10);

window.addEventListener('scroll', optimizedScroll);

// Toast notification system
function showToast(message, type = 'info', duration = 3000) {
    const toast = document.createElement('div');
    toast.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    toast.style.cssText = `
        top: 100px;
        right: 20px;
        z-index: 1050;
        max-width: 400px;
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
    `;
    
    toast.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(toast);
    
    // Auto remove after duration
    setTimeout(() => {
        if (toast.parentNode) {
            toast.remove();
        }
    }, duration);
}

// Loading state management
function setLoadingState(element, isLoading) {
    if (isLoading) {
        element.disabled = true;
        element.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Loading...';
    } else {
        element.disabled = false;
        element.innerHTML = element.getAttribute('data-original-text') || 'Submit';
    }
}

// Initialize loading states for buttons
document.querySelectorAll('button[type="submit"]').forEach(button => {
    button.setAttribute('data-original-text', button.textContent);
});

// Handle form submissions with loading states
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', function() {
        const submitButton = this.querySelector('button[type="submit"]');
        if (submitButton) {
            setLoadingState(submitButton, true);
        }
    });
});

// Error handling for images
document.querySelectorAll('img').forEach(img => {
    img.addEventListener('error', function() {
        this.style.display = 'none';
    });
});

// Progressive enhancement for older browsers
if (!window.IntersectionObserver) {
    // Fallback for browsers without IntersectionObserver
    document.querySelectorAll('.stat-number').forEach(element => {
        const target = parseInt(element.getAttribute('data-target'));
        element.textContent = target;
    });
}

// Enhanced interactive features
function initTooltips() {
    // Initialize Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

function initProgressBars() {
    // Animate progress bars when they come into view
    const progressBars = document.querySelectorAll('.progress-bar');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const progressBar = entry.target;
                const width = progressBar.getAttribute('data-width') || progressBar.style.width;
                progressBar.style.width = '0%';
                setTimeout(() => {
                    progressBar.style.transition = 'width 2s ease-in-out';
                    progressBar.style.width = width;
                }, 200);
                observer.unobserve(progressBar);
            }
        });
    });
    
    progressBars.forEach(bar => observer.observe(bar));
}

function initParallaxEffects() {
    // Simple parallax effect for hero sections
    const parallaxElements = document.querySelectorAll('.parallax-element');
    
    if (parallaxElements.length > 0) {
        window.addEventListener('scroll', debounce(() => {
            const scrolled = window.pageYOffset;
            const rate = scrolled * -0.5;
            
            parallaxElements.forEach(element => {
                element.style.transform = `translateY(${rate}px)`;
            });
        }, 10));
    }
}

function initTypingAnimation() {
    // Typing animation for text elements
    const typingElements = document.querySelectorAll('.typing-text');
    
    typingElements.forEach(element => {
        const text = element.textContent;
        element.textContent = '';
        element.style.borderRight = '2px solid';
        element.style.animation = 'blink 1s infinite';
        
        let i = 0;
        const typeWriter = () => {
            if (i < text.length) {
                element.textContent += text.charAt(i);
                i++;
                setTimeout(typeWriter, 100);
            } else {
                element.style.animation = 'none';
                element.style.borderRight = 'none';
            }
        };
        
        // Start typing when element comes into view
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    setTimeout(typeWriter, 500);
                    observer.unobserve(entry.target);
                }
            });
        });
        
        observer.observe(element);
    });
}

function initLoadingStates() {
    // Enhanced loading states for buttons and forms
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function() {
            const submitButton = this.querySelector('button[type="submit"]');
            if (submitButton && !submitButton.disabled) {
                setLoadingState(submitButton, true);
                
                // Add a timeout to reset loading state if form submission takes too long
                setTimeout(() => {
                    setLoadingState(submitButton, false);
                }, 10000);
            }
        });
    });
}

function initAdvancedAnimations() {
    // Card hover effects
    document.querySelectorAll('.card').forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
            this.style.transition = 'transform 0.3s ease';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
    
    // Button ripple effect
    document.querySelectorAll('.btn').forEach(button => {
        button.addEventListener('click', function(e) {
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            ripple.classList.add('ripple');
            
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });
}

// Initialize all enhanced features
document.addEventListener('DOMContentLoaded', function() {
    initNavigation();
    initHeroAnimations();
    initStatsCounter();
    initProjectFilters();
    initTestimonialCarousel();
    initScrollAnimations();
    initFormValidation();
    initServiceSelector();
    initSmoothScrolling();
    initTooltips();
    initProgressBars();
    initParallaxEffects();
    initTypingAnimation();
    initLoadingStates();
    initAdvancedAnimations();
});

// Export functions for external use
window.NikojiTech = {
    showToast,
    setLoadingState,
    debounce,
    initTooltips,
    initProgressBars,
    initParallaxEffects,
    initTypingAnimation
};
