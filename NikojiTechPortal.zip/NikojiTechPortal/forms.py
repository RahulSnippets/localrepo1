from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SelectField, SubmitField
from wtforms.validators import DataRequired, Email, Length

class ContactForm(FlaskForm):
    name = StringField('Full Name', validators=[
        DataRequired(message='Name is required'),
        Length(min=2, max=100, message='Name must be between 2 and 100 characters')
    ])
    
    email = StringField('Email Address', validators=[
        DataRequired(message='Email is required'),
        Email(message='Please enter a valid email address')
    ])
    
    company = StringField('Company Name', validators=[
        Length(max=100, message='Company name must be less than 100 characters')
    ])
    
    service = SelectField('Service Interest', choices=[
        ('', 'Select a service...'),
        ('automation', 'Automation'),
        ('innovation', 'Innovation'),
        ('design_development', 'Design & Development'),
        ('testing_service', 'Testing & Service'),
        ('software_development', 'Software Development'),
        ('requirements', 'Requirements Gathering'),
        ('ems_solutions', 'EMS Solutions'),
        ('consultancy', 'Consultancy')
    ], validators=[DataRequired(message='Please select a service')])
    
    message = TextAreaField('Message', validators=[
        DataRequired(message='Message is required'),
        Length(min=10, max=1000, message='Message must be between 10 and 1000 characters')
    ])
    
    submit = SubmitField('Send Message')

class NewsletterForm(FlaskForm):
    email = StringField('Email', validators=[
        DataRequired(message='Email is required'),
        Email(message='Please enter a valid email address')
    ])
    
    submit = SubmitField('Subscribe')