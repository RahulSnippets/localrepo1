# Admin Panel Access Guide

## Admin Panel Location

**URL:** `/admin` or `/admin/`

**Direct Link:** `https://your-domain.com/admin`

## Access Methods

### 1. Footer Access (Discrete)
- Small dot (•) in the bottom right of the footer
- Appears with low opacity for security
- Hover to see "Management Portal" tooltip
- Click to access admin dashboard

### 2. Direct URL Access
- Navigate directly to `/admin` in your browser
- Bookmark for quick access
- Add to browser favorites

## Admin Panel Features

### Dashboard (`/admin/`)
- Overview statistics for contacts and subscribers
- Recent activity monitoring
- Quick access to all management sections
- Interactive charts showing monthly trends
- Service interest distribution

### Contact Management (`/admin/contacts`)
- View all contact form submissions
- Filter by status (new, contacted, resolved)
- Update contact status
- View full messages
- Email integration for quick replies
- Pagination for large datasets

### Newsletter Management (`/admin/newsletters`)
- Manage newsletter subscribers
- View subscription dates
- Activate/deactivate subscribers
- Handle duplicate email prevention
- Export subscriber lists

### File Management (`/admin/files`)
- Upload company brochures (PDF)
- Manage project images
- Store testimonial photos
- General file storage
- File type validation
- Download and preview capabilities

### Quick Contact (`/admin/quick-contact`)
- Real-time new message alerts
- Quick reply functionality
- Status updates
- Auto-refresh for new submissions

## Security Features

1. **Discrete Access**
   - Hidden footer link (small dot)
   - No obvious admin menu
   - Low-profile design

2. **File Upload Security**
   - File type validation
   - Size limitations (10MB max)
   - Secure filename handling
   - Virus scanning recommended

3. **Database Security**
   - SQL injection protection
   - Input validation
   - Error handling
   - Logging system

## Usage Instructions

### Accessing New Contact Messages
1. Visit `/admin` or click the footer dot
2. Check dashboard for new message count
3. Click "Quick Contact" for immediate access
4. Use "View All Contacts" for complete list

### Managing Newsletter Subscribers
1. Navigate to Newsletter section
2. Filter by active/inactive status
3. Toggle subscriber status as needed
4. Monitor subscription trends

### Uploading Files
1. Go to File Management section
2. Click "Upload File"
3. Select file type (brochure, image, etc.)
4. Choose file and upload
5. Files stored in `static/uploads/`

## File Organization

### Upload Directory Structure
```
static/uploads/
├── brochures/     (Company brochures)
├── projects/      (Project images)
├── testimonials/  (Client photos)
└── general/       (Other files)
```

### Supported File Types
- **Documents:** PDF, DOC, DOCX, TXT
- **Images:** PNG, JPG, JPEG, GIF
- **Size Limit:** 10MB per file

## Database Access

### Direct Database Queries
Use the provided SQL queries for advanced operations:

```sql
-- View recent contacts
SELECT * FROM contact_submissions 
ORDER BY submitted_at DESC LIMIT 10;

-- Check newsletter statistics
SELECT COUNT(*) as total_subscribers,
       COUNT(CASE WHEN is_active THEN 1 END) as active_subscribers
FROM newsletter_subscribers;

-- Service interest analysis
SELECT service, COUNT(*) as count 
FROM contact_submissions 
WHERE service IS NOT NULL 
GROUP BY service 
ORDER BY count DESC;
```

## Maintenance Tasks

### Daily Tasks
1. Check new contact messages
2. Respond to priority inquiries
3. Monitor system logs
4. Backup important data

### Weekly Tasks
1. Review newsletter subscriber growth
2. Clean up old files if needed
3. Update contact status
4. Analyze service interest trends

### Monthly Tasks
1. Database performance review
2. Security audit
3. Backup verification
4. System updates

## Troubleshooting

### Common Issues

1. **Cannot Access Admin Panel**
   - Check URL spelling: `/admin`
   - Clear browser cache
   - Verify server is running

2. **File Upload Fails**
   - Check file size (max 10MB)
   - Verify file type is supported
   - Ensure upload directory permissions

3. **Database Connection Issues**
   - Verify environment variables
   - Check PostgreSQL service
   - Review connection logs

### Getting Help

1. **Error Logs**
   - Check server logs for errors
   - Monitor database query logs
   - Review application logs

2. **Performance Issues**
   - Monitor database query times
   - Check server resources
   - Optimize large datasets

## Best Practices

### Security
1. Change default passwords
2. Use HTTPS in production
3. Regular security updates
4. Monitor access logs

### Performance
1. Regular database cleanup
2. Optimize images before upload
3. Monitor disk space
4. Use CDN for static files

### Data Management
1. Regular backups
2. Data validation
3. Error handling
4. User input sanitization

## Emergency Procedures

### Database Backup
```bash
pg_dump -h hostname -U username database_name > backup_$(date +%Y%m%d).sql
```

### File Backup
```bash
tar -czf uploads_backup_$(date +%Y%m%d).tar.gz static/uploads/
```

### System Recovery
1. Stop application
2. Restore database from backup
3. Restore files from backup
4. Restart application
5. Verify functionality

This admin panel provides comprehensive management capabilities for the Nikoji Technologies website with robust security and user-friendly interfaces.