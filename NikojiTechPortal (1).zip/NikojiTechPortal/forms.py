from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, TextAreaField, SelectField, SubmitField, DateField, BooleanField, IntegerField
from wtforms.validators import DataRequired, Email, Length, Optional, NumberRange

class ContactForm(FlaskForm):
    name = StringField('Full Name', validators=[
        DataRequired(message='Name is required'),
        Length(min=2, max=100, message='Name must be between 2 and 100 characters')
    ])
    
    email = StringField('Email Address', validators=[
        DataRequired(message='Email is required'),
        Email(message='Please enter a valid email address')
    ])
    
    company = StringField('Company Name', validators=[
        Length(max=100, message='Company name must be less than 100 characters')
    ])
    
    service = SelectField('Service Interest', choices=[
        ('', 'Select a service...'),
        ('automation', 'Automation'),
        ('innovation', 'Innovation'),
        ('design_development', 'Design & Development'),
        ('testing_service', 'Testing & Service'),
        ('software_development', 'Software Development'),
        ('requirements', 'Requirements Gathering'),
        ('ems_solutions', 'EMS Solutions'),
        ('consultancy', 'Consultancy')
    ], validators=[DataRequired(message='Please select a service')])
    
    message = TextAreaField('Message', validators=[
        DataRequired(message='Message is required'),
        Length(min=10, max=1000, message='Message must be between 10 and 1000 characters')
    ])
    
    submit = SubmitField('Send Message')

class NewsletterForm(FlaskForm):
    email = StringField('Email', validators=[
        DataRequired(message='Email is required'),
        Email(message='Please enter a valid email address')
    ])
    
    submit = SubmitField('Subscribe')

class ProjectForm(FlaskForm):
    title = StringField('Project Title', validators=[
        DataRequired(message='Title is required'),
        Length(min=5, max=200, message='Title must be between 5 and 200 characters')
    ])
    
    description = TextAreaField('Project Description', validators=[
        DataRequired(message='Description is required'),
        Length(min=50, max=2000, message='Description must be between 50 and 2000 characters')
    ])
    
    category = SelectField('Category', choices=[
        ('automation', 'Automation'),
        ('software', 'Software Development'),
        ('design', 'Design & Development'),
        ('ems', 'EMS Solutions')
    ], validators=[DataRequired(message='Please select a category')])
    
    technologies = StringField('Technologies Used', validators=[
        Length(max=500, message='Technologies list must be less than 500 characters')
    ])
    
    client_name = StringField('Client Name', validators=[
        Length(max=100, message='Client name must be less than 100 characters')
    ])
    
    project_date = DateField('Project Date', validators=[Optional()])
    
    status = SelectField('Status', choices=[
        ('completed', 'Completed'),
        ('ongoing', 'Ongoing'),
        ('planned', 'Planned')
    ], default='completed')
    
    featured = BooleanField('Featured Project')
    
    submit = SubmitField('Save Project')

class FileUploadForm(FlaskForm):
    file = FileField('Choose File', validators=[
        DataRequired(message='Please select a file'),
        FileAllowed(['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png', 'gif'], 
                   'Only PDF, DOC, DOCX, and image files are allowed')
    ])
    
    upload_type = SelectField('File Type', choices=[
        ('brochure', 'Brochure'),
        ('project_image', 'Project Image'),
        ('testimonial_image', 'Testimonial Image'),
        ('general', 'General Document')
    ], validators=[DataRequired(message='Please select file type')])
    
    uploaded_by = StringField('Uploaded By', validators=[
        Length(max=100, message='Name must be less than 100 characters')
    ])
    
    submit = SubmitField('Upload File')

class TestimonialForm(FlaskForm):
    client_name = StringField('Client Name', validators=[
        DataRequired(message='Client name is required'),
        Length(min=2, max=100, message='Client name must be between 2 and 100 characters')
    ])
    
    company = StringField('Company', validators=[
        DataRequired(message='Company is required'),
        Length(min=2, max=100, message='Company must be between 2 and 100 characters')
    ])
    
    position = StringField('Position/Title', validators=[
        Length(max=100, message='Position must be less than 100 characters')
    ])
    
    testimonial_text = TextAreaField('Testimonial', validators=[
        DataRequired(message='Testimonial text is required'),
        Length(min=20, max=1000, message='Testimonial must be between 20 and 1000 characters')
    ])
    
    rating = SelectField('Rating', choices=[
        ('', 'Select rating...'),
        ('5', '5 Stars'),
        ('4', '4 Stars'),
        ('3', '3 Stars'),
        ('2', '2 Stars'),
        ('1', '1 Star')
    ], coerce=int, validators=[Optional()])
    
    project_type = StringField('Project Type', validators=[
        Length(max=50, message='Project type must be less than 50 characters')
    ])
    
    is_featured = BooleanField('Featured Testimonial')
    
    submit = SubmitField('Save Testimonial')

class ContactUpdateForm(FlaskForm):
    phone = StringField('Phone Number', validators=[
        Length(max=20, message='Phone number must be less than 20 characters')
    ])
    
    email = StringField('Email Address', validators=[
        DataRequired(message='Email is required'),
        Email(message='Please enter a valid email address')
    ])
    
    address = TextAreaField('Address', validators=[
        Length(max=500, message='Address must be less than 500 characters')
    ])
    
    business_hours = StringField('Business Hours', validators=[
        Length(max=100, message='Business hours must be less than 100 characters')
    ])
    
    submit = SubmitField('Update Contact Info')