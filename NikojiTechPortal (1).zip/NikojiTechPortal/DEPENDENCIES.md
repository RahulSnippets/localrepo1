# Dependencies for Nikoji Technologies Website

This file contains all the required Python packages for the Nikoji Technologies Flask application.

## Core Dependencies

### Flask Framework
```
Flask==2.3.3
```
- Main web framework
- Handles routing, templates, and HTTP requests

### Database
```
Flask-SQLAlchemy==3.0.5
psycopg2-binary==2.9.7
```
- Flask-SQLAlchemy: Database ORM integration
- psycopg2-binary: PostgreSQL adapter for Python

### Forms and Security
```
Flask-WTF==1.1.1
WTForms==3.0.1
email-validator==2.0.0
```
- Flask-WTF: CSRF protection and form handling
- WTForms: Form validation and rendering
- email-validator: Email field validation

### Web Server
```
gunicorn==21.2.0
Werkzeug==2.3.7
```
- gunicorn: WSGI HTTP Server for production
- Werkzeug: WSGI utility library (Flask dependency)

### Configuration Management
```
python-dotenv==1.0.0
```
- Environment variable management from .env files

## Installation Commands

### For Development
```bash
pip install Flask==2.3.3
pip install Flask-SQLAlchemy==3.0.5
pip install Flask-WTF==1.1.1
pip install WTForms==3.0.1
pip install email-validator==2.0.0
pip install gunicorn==21.2.0
pip install psycopg2-binary==2.9.7
pip install Werkzeug==2.3.7
pip install python-dotenv==1.0.0
```

### All at Once
```bash
pip install Flask==2.3.3 Flask-SQLAlchemy==3.0.5 Flask-WTF==1.1.1 WTForms==3.0.1 email-validator==2.0.0 gunicorn==21.2.0 psycopg2-binary==2.9.7 Werkzeug==2.3.7 python-dotenv==1.0.0
```

## Optional Development Dependencies

### Code Quality
```bash
pip install black==23.3.0          # Code formatter
pip install flake8==6.0.0          # Linting
pip install pylint==2.17.4         # Advanced linting
```

### Testing
```bash
pip install pytest==7.4.0          # Testing framework
pip install pytest-flask==1.2.0    # Flask testing utilities
pip install pytest-cov==4.1.0      # Coverage reporting
```

### Development Tools
```bash
pip install flask-shell-ipython==1.4.0  # Enhanced shell
pip install watchdog==3.0.0             # File watching
```

## Requirements.txt Content

Create a `requirements.txt` file with this content:

```
Flask==2.3.3
Flask-SQLAlchemy==3.0.5
Flask-WTF==1.1.1
WTForms==3.0.1
email-validator==2.0.0
gunicorn==21.2.0
psycopg2-binary==2.9.7
Werkzeug==2.3.7
python-dotenv==1.0.0
```

## Platform-Specific Notes

### Windows
- psycopg2-binary is recommended over psycopg2
- May need Microsoft Visual C++ Build Tools

### macOS
- May need to install PostgreSQL via Homebrew first
- Xcode command line tools may be required

### Linux (Ubuntu/Debian)
```bash
sudo apt-get install python3-dev postgresql-server-dev-all
```

### Linux (CentOS/RHEL)
```bash
sudo yum install python3-devel postgresql-devel
```

## Version Compatibility

### Python Versions
- Minimum: Python 3.8
- Recommended: Python 3.9+
- Tested on: Python 3.8, 3.9, 3.10, 3.11

### Database Versions
- PostgreSQL 12+
- Tested on: PostgreSQL 12, 13, 14, 15

## Security Considerations

### Production Dependencies
All listed packages are suitable for production use with proper configuration.

### Known Vulnerabilities
Check for security updates regularly:
```bash
pip list --outdated
pip audit  # If available
```

### Updates
Update dependencies carefully and test thoroughly:
```bash
pip install --upgrade package_name
```

## Troubleshooting

### Common Installation Issues

1. **psycopg2 installation fails:**
   ```bash
   pip install psycopg2-binary
   # Instead of psycopg2
   ```

2. **Permission errors:**
   ```bash
   pip install --user package_name
   # Or use virtual environment
   ```

3. **Build tools missing:**
   - Windows: Install Microsoft C++ Build Tools
   - macOS: Install Xcode command line tools
   - Linux: Install development packages

### Virtual Environment Setup
```bash
python -m venv venv
source venv/bin/activate  # Linux/macOS
venv\Scripts\activate     # Windows
pip install -r requirements.txt
```

## Environment-Specific Installations

### Development Environment
```bash
pip install -r requirements.txt
pip install black flake8 pytest pytest-flask
```

### Production Environment
```bash
pip install -r requirements.txt --no-dev
```

### Docker Environment
```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .
CMD ["gunicorn", "--bind", "0.0.0.0:5000", "main:app"]
```

## Package Descriptions

### Flask==2.3.3
- Web framework for Python
- Handles HTTP requests and responses
- Template rendering with Jinja2
- Session management

### Flask-SQLAlchemy==3.0.5
- SQLAlchemy integration for Flask
- Database model definitions
- Query interface
- Migration support

### Flask-WTF==1.1.1
- Form handling for Flask
- CSRF protection
- File upload support
- Form validation integration

### WTForms==3.0.1
- Form validation and rendering
- Field types and validators
- Cross-site request forgery protection
- HTML form generation

### email-validator==2.0.0
- Email address validation
- DNS checking capabilities
- Internationalized domain support
- Deliverability validation

### gunicorn==21.2.0
- Python WSGI HTTP Server
- Production-ready web server
- Worker process management
- Performance optimization

### psycopg2-binary==2.9.7
- PostgreSQL adapter for Python
- Binary distribution (no compilation needed)
- Connection pooling
- Advanced PostgreSQL features

### Werkzeug==2.3.7
- WSGI utility library
- Development server
- Request/response objects
- URL routing utilities

### python-dotenv==1.0.0
- Environment variable management
- .env file loading
- Configuration management
- Development/production separation