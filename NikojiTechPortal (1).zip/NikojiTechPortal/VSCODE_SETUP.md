# VS Code Development Setup for Nikoji Technologies

This guide helps you set up a complete development environment for the Nikoji Technologies Flask website using Visual Studio Code.

## Prerequisites

- Visual Studio Code (latest version)
- Python 3.8+ installed
- PostgreSQL 12+ installed
- Git (for version control)

## Step 1: VS Code Extensions

### Essential Extensions
Install these extensions from the VS Code marketplace:

```
1. Python (Microsoft) - Python language support
2. Python Debugger (Microsoft) - Debugging support
3. Pylance (Microsoft) - Advanced Python language server
4. SQLTools (Matheus Teixeira) - Database management
5. SQLTools PostgreSQL Driver - PostgreSQL support
6. Flask Snippets (cstrap) - Flask code snippets
7. HTML CSS Support (ecmel) - Web development support
8. Auto Rename Tag (Jun Han) - HTML tag editing
9. Bracket Pair Colorizer 2 (CoenraadS) - Code readability
10. GitLens (GitKraken) - Enhanced Git capabilities
```

### Optional Extensions
```
11. Better Comments (Aaron Bond) - Enhanced commenting
12. Error Lens (Alexander) - Inline error display
13. Thunder Client (RangaVadhineni) - API testing
14. Live Server (Ritwick Dey) - Static file serving
15. Material Icon Theme (Philipp Kief) - File icons
```

## Step 2: Python Environment Setup

### 2.1 Virtual Environment
```bash
# Create project directory
mkdir nikoji-technologies
cd nikoji-technologies

# Create virtual environment
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate
```

### 2.2 Install Dependencies
```bash
pip install Flask==2.3.3
pip install Flask-SQLAlchemy==3.0.5
pip install Flask-WTF==1.1.1
pip install WTForms==3.0.1
pip install email-validator==2.0.0
pip install gunicorn==21.2.0
pip install psycopg2-binary==2.9.7
pip install Werkzeug==2.3.7
pip install python-dotenv==1.0.0

# Development dependencies
pip install black==23.3.0
pip install flake8==6.0.0
pip install pytest==7.4.0
pip install pytest-flask==1.2.0
```

### 2.3 Generate requirements.txt
```bash
pip freeze > requirements.txt
```

## Step 3: VS Code Workspace Configuration

### 3.1 Create Workspace Settings
Create `.vscode/settings.json`:

```json
{
    "python.defaultInterpreterPath": "./venv/bin/python",
    "python.envFile": "${workspaceFolder}/.env",
    "python.linting.enabled": true,
    "python.linting.flake8Enabled": true,
    "python.linting.pylintEnabled": false,
    "python.formatting.provider": "black",
    "python.formatting.blackArgs": ["--line-length", "88"],
    "python.testing.pytestEnabled": true,
    "python.testing.unittestEnabled": false,
    "python.testing.pytestArgs": ["tests"],
    "files.exclude": {
        "**/__pycache__": true,
        "**/*.pyc": true,
        "**/venv": true,
        "**/.pytest_cache": true
    },
    "emmet.includeLanguages": {
        "jinja-html": "html"
    },
    "files.associations": {
        "*.html": "jinja-html"
    },
    "html.suggest.html5": true,
    "css.validate": true,
    "editor.formatOnSave": true,
    "editor.rulers": [88],
    "sqltools.connections": [
        {
            "name": "Nikoji PostgreSQL",
            "driver": "PostgreSQL",
            "server": "localhost",
            "port": 5432,
            "database": "nikoji_tech_db",
            "username": "nikoji_user",
            "password": "",
            "askForPassword": true
        }
    ]
}
```

### 3.2 Launch Configuration
Create `.vscode/launch.json`:

```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Flask App",
            "type": "python",
            "request": "launch",
            "program": "${workspaceFolder}/main.py",
            "env": {
                "FLASK_ENV": "development",
                "FLASK_DEBUG": "1"
            },
            "args": [],
            "jinja": true,
            "console": "integratedTerminal"
        },
        {
            "name": "Flask App (Production Mode)",
            "type": "python",
            "request": "launch",
            "program": "${workspaceFolder}/main.py",
            "env": {
                "FLASK_ENV": "production",
                "FLASK_DEBUG": "0"
            },
            "args": [],
            "console": "integratedTerminal"
        },
        {
            "name": "Python: Current File",
            "type": "python",
            "request": "launch",
            "program": "${file}",
            "console": "integratedTerminal"
        }
    ]
}
```

### 3.3 Tasks Configuration
Create `.vscode/tasks.json`:

```json
{
    "version": "2.0.0",
    "tasks": [
        {
            "label": "Run Flask Development Server",
            "type": "shell",
            "command": "${workspaceFolder}/venv/bin/python",
            "args": ["main.py"],
            "group": {
                "kind": "build",
                "isDefault": true
            },
            "presentation": {
                "echo": true,
                "reveal": "always",
                "focus": false,
                "panel": "shared"
            },
            "options": {
                "env": {
                    "FLASK_ENV": "development",
                    "FLASK_DEBUG": "1"
                }
            },
            "problemMatcher": []
        },
        {
            "label": "Run Tests",
            "type": "shell",
            "command": "${workspaceFolder}/venv/bin/python",
            "args": ["-m", "pytest", "tests/", "-v"],
            "group": "test",
            "presentation": {
                "echo": true,
                "reveal": "always",
                "focus": false,
                "panel": "shared"
            }
        },
        {
            "label": "Format Code with Black",
            "type": "shell",
            "command": "${workspaceFolder}/venv/bin/python",
            "args": ["-m", "black", "."],
            "group": "build",
            "presentation": {
                "echo": true,
                "reveal": "always",
                "focus": false,
                "panel": "shared"
            }
        },
        {
            "label": "Lint Code with Flake8",
            "type": "shell",
            "command": "${workspaceFolder}/venv/bin/python",
            "args": ["-m", "flake8", "."],
            "group": "build",
            "presentation": {
                "echo": true,
                "reveal": "always",
                "focus": false,
                "panel": "shared"
            }
        }
    ]
}
```

## Step 4: PostgreSQL Setup

### 4.1 Install PostgreSQL
Download and install PostgreSQL from: https://www.postgresql.org/download/

### 4.2 Create Database
```sql
-- Connect as postgres user
psql -U postgres

-- Create database
CREATE DATABASE nikoji_tech_db;

-- Create user
CREATE USER nikoji_user WITH PASSWORD 'your_secure_password';

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE nikoji_tech_db TO nikoji_user;

-- Exit
\q
```

### 4.3 Configure SQLTools Connection
1. Open Command Palette (Ctrl+Shift+P)
2. Search "SQLTools: Add New Connection"
3. Select PostgreSQL
4. Fill in connection details:
   - Name: Nikoji PostgreSQL
   - Server: localhost
   - Port: 5432
   - Database: nikoji_tech_db
   - Username: nikoji_user
   - Password: [your_password]

## Step 5: Environment Configuration

### 5.1 Create .env File
```env
# Flask Configuration
FLASK_ENV=development
FLASK_DEBUG=True
SESSION_SECRET=your-random-secret-key-minimum-32-characters

# Database Configuration
DATABASE_URL=postgresql://nikoji_user:your_password@localhost:5432/nikoji_tech_db
PGHOST=localhost
PGPORT=5432
PGDATABASE=nikoji_tech_db
PGUSER=nikoji_user
PGPASSWORD=your_password

# Application Settings
UPLOAD_FOLDER=static/uploads
MAX_CONTENT_LENGTH=16777216
ALLOWED_EXTENSIONS=pdf,doc,docx,jpg,jpeg,png,gif

# Security Settings
WTF_CSRF_ENABLED=True
WTF_CSRF_TIME_LIMIT=3600
```

### 5.2 Create .gitignore
```gitignore
# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
venv/
env/
ENV/

# Flask
instance/
.webassets-cache

# Environment
.env
.env.local
.env.development.local
.env.test.local
.env.production.local

# Database
*.db
*.sqlite

# Uploads
static/uploads/*
!static/uploads/.gitkeep

# IDE
.vscode/settings.json
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Logs
*.log

# Testing
.pytest_cache/
.coverage
htmlcov/

# Build
dist/
build/
*.egg-info/
```

## Step 6: Project Structure Setup

### 6.1 Recommended Directory Structure
```
nikoji-technologies/
├── .vscode/
│   ├── settings.json
│   ├── launch.json
│   └── tasks.json
├── static/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── main.js
│   ├── images/
│   │   └── logo.png
│   └── uploads/
│       └── .gitkeep
├── templates/
│   ├── admin/
│   │   ├── contacts.html
│   │   ├── dashboard.html
│   │   ├── files.html
│   │   ├── newsletters.html
│   │   ├── quick_contact.html
│   │   └── upload.html
│   ├── base.html
│   ├── index.html
│   ├── contact.html
│   ├── about.html
│   ├── projects.html
│   ├── privacy-policy.html
│   ├── terms-of-service.html
│   └── [service pages]
├── tests/
│   ├── __init__.py
│   ├── conftest.py
│   ├── test_app.py
│   ├── test_models.py
│   └── test_routes.py
├── main.py
├── app.py
├── routes.py
├── models.py
├── forms.py
├── admin.py
├── .env
├── .gitignore
├── requirements.txt
└── README.md
```

### 6.2 Create Upload Directory
```bash
mkdir -p static/uploads
touch static/uploads/.gitkeep
```

## Step 7: Testing Setup

### 7.1 Create Test Directory
```bash
mkdir tests
touch tests/__init__.py
```

### 7.2 Create conftest.py
```python
import pytest
import os
import tempfile
from app import app, db

@pytest.fixture
def client():
    # Create a temporary file to serve as the database
    db_fd, app.config['DATABASE'] = tempfile.mkstemp()
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['WTF_CSRF_ENABLED'] = False

    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            yield client
            db.drop_all()

    os.close(db_fd)
    os.unlink(app.config['DATABASE'])
```

### 7.3 Create test_app.py
```python
def test_homepage(client):
    """Test the homepage loads correctly."""
    response = client.get('/')
    assert response.status_code == 200
    assert b'Nikoji Technologies' in response.data

def test_contact_page(client):
    """Test the contact page loads correctly."""
    response = client.get('/contact')
    assert response.status_code == 200
    assert b'Contact' in response.data

def test_admin_dashboard(client):
    """Test admin dashboard access."""
    response = client.get('/admin/')
    assert response.status_code == 200
```

## Step 8: Development Workflow

### 8.1 Daily Development
1. Open VS Code in project directory
2. Activate virtual environment (should be automatic)
3. Start Flask development server (F5 or Ctrl+F5)
4. Make changes and test
5. Run tests before committing

### 8.2 Debugging
- Set breakpoints in Python code
- Use VS Code debugger (F5)
- Check Debug Console for variables
- Use SQLTools to inspect database

### 8.3 Code Quality
```bash
# Format code
python -m black .

# Lint code
python -m flake8 .

# Run tests
python -m pytest tests/ -v
```

## Step 9: Git Integration

### 9.1 Initialize Repository
```bash
git init
git add .
git commit -m "Initial commit: Nikoji Technologies website"
```

### 9.2 Connect to Remote Repository
```bash
git remote add origin [your-repository-url]
git push -u origin main
```

### 9.3 GitLens Features
- View line-by-line Git blame
- Compare file changes
- Explore repository history
- Manage branches visually

## Step 10: Deployment Preparation

### 10.1 Environment Variables
Create separate .env files for different environments:
- `.env.development`
- `.env.staging`
- `.env.production`

### 10.2 Configuration Management
```python
# In app.py
import os
from dotenv import load_dotenv

# Load environment-specific .env file
env_file = f".env.{os.getenv('FLASK_ENV', 'development')}"
load_dotenv(env_file)
```

### 10.3 Production Checklist
- [ ] Set FLASK_ENV=production
- [ ] Set FLASK_DEBUG=False
- [ ] Use strong SESSION_SECRET
- [ ] Configure production database
- [ ] Set up proper logging
- [ ] Enable HTTPS
- [ ] Configure static file serving

## Troubleshooting

### Common Issues

1. **Python interpreter not found:**
   - Check virtual environment activation
   - Verify interpreter path in settings

2. **Module import errors:**
   - Ensure virtual environment is activated
   - Check PYTHONPATH configuration

3. **Database connection errors:**
   - Verify PostgreSQL is running
   - Check connection credentials
   - Test SQLTools connection

4. **Template not found errors:**
   - Check template directory structure
   - Verify file names and paths

### Performance Tips
- Use code folding for large files
- Enable minimap for navigation
- Use multi-cursor editing
- Utilize IntelliSense suggestions

## Keyboard Shortcuts

### Essential Shortcuts
- `Ctrl+Shift+P`: Command Palette
- `F5`: Start Debugging
- `Ctrl+F5`: Run Without Debugging
- `Ctrl+Shift+F`: Global Search
- `Ctrl+Shift+E`: Explorer Panel
- `Ctrl+Shift+G`: Source Control
- `Ctrl+Shift+D`: Debug Panel
- `Ctrl+Shift+X`: Extensions
- `Ctrl+``: Terminal Toggle
- `F12`: Go to Definition

### Flask-Specific
- `Ctrl+Shift+P` > "Python: Run Current File"
- `Ctrl+Shift+P` > "SQLTools: Run Query"
- `Ctrl+Shift+P` > "Thunder Client: New Request"

## Additional Resources

- [VS Code Python Tutorial](https://code.visualstudio.com/docs/python/python-tutorial)
- [Flask Documentation](https://flask.palletsprojects.com/)
- [SQLAlchemy Documentation](https://docs.sqlalchemy.org/)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)

## Support

For VS Code specific issues:
- Check VS Code documentation
- Review extension documentation
- Use built-in help system

For Flask development issues:
- Review Flask documentation
- Check Python and Flask communities
- Use debugging tools and error logs