# Nikoji Technologies - Industrial Automation Website

A professional Flask-based website for Nikoji Technologies, showcasing comprehensive industrial automation services, project portfolio, and client engagement capabilities.

## 🏢 About Nikoji Technologies

Nikoji Technologies specializes in industrial automation solutions, providing cutting-edge services in:
- Process Automation & Control Systems
- Innovation & Technology Consulting
- Custom Software Development
- Design & Development Services
- Testing & Quality Assurance
- Requirements Engineering
- EMS (Electronic Manufacturing Services)
- Technical Consultancy

## 🚀 Features

### Public Features
- **Responsive Design**: Mobile-first approach with Bootstrap 5
- **Service Portfolio**: Detailed service pages with capabilities
- **Project Showcase**: Featured projects with filtering capabilities
- **Contact Management**: Professional contact forms with validation
- **Newsletter System**: Email subscription management
- **Privacy & Terms**: Comprehensive legal pages
- **SEO Optimized**: Meta tags and structured data

### Admin Panel Features
- **Dashboard Analytics**: Real-time statistics and metrics
- **Contact Management**: Handle inquiries and submissions
- **Newsletter Management**: Subscriber administration
- **File Management**: Upload and manage brochures/documents
- **Project Management**: Add and update project portfolio
- **Quick Contact Updates**: Manage contact information

## 🛠️ Technology Stack

- **Backend**: Python 3.11, Flask 2.3+
- **Database**: PostgreSQL with SQLAlchemy ORM
- **Frontend**: Bootstrap 5, JavaScript (ES6+)
- **Forms**: Flask-WTF with CSRF protection
- **File Handling**: Secure upload management
- **Deployment**: Gunicorn WSGI server

## 📋 Prerequisites

- Python 3.11+
- PostgreSQL 12+
- Git (for version control)

## 🔧 Installation & Setup

### 1. Clone Repository
```bash
git clone <repository-url>
cd nikoji-technologies
```

### 2. Environment Setup
```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Database Configuration
```bash
# Create PostgreSQL database
createdb nikoji_tech_db

# Create database user
psql -c "CREATE USER nikoji_user WITH PASSWORD 'your_password';"
psql -c "GRANT ALL PRIVILEGES ON DATABASE nikoji_tech_db TO nikoji_user;"
```

### 5. Environment Variables
Create `.env` file:
```env
DATABASE_URL=postgresql://nikoji_user:your_password@localhost:5432/nikoji_tech_db
SESSION_SECRET=your_random_secret_key_minimum_32_characters
FLASK_ENV=development
FLASK_DEBUG=true
```

### 6. Initialize Database
```bash
python main.py
```

## 🚀 Running the Application

### Development Mode
```bash
python main.py
```

### Production Mode
```bash
gunicorn --bind 0.0.0.0:5000 --workers 4 main:app
```

The application will be available at `http://localhost:5000`

## 📁 Project Structure

```
nikoji-technologies/
├── main.py                 # Application entry point
├── app.py                  # Flask app configuration
├── models.py               # Database models
├── routes.py               # Public routes
├── admin.py                # Admin panel routes
├── forms.py                # WTForms definitions
├── requirements.txt        # Python dependencies
├── static/
│   ├── css/
│   │   └── style.css      # Custom styles
│   ├── js/
│   │   └── main.js        # JavaScript functionality
│   ├── images/            # Image assets
│   └── uploads/           # User uploaded files
├── templates/
│   ├── base.html          # Base template
│   ├── index.html         # Homepage
│   ├── services/          # Service pages
│   ├── admin/             # Admin templates
│   └── legal/             # Privacy & Terms pages
└── docs/                  # Documentation
```

## 🗄️ Database Schema

### Core Tables
- `contact_submissions` - Contact form submissions
- `newsletter_subscribers` - Email subscribers
- `projects` - Project portfolio
- `service_inquiries` - Service-specific inquiries
- `testimonials` - Client testimonials
- `file_uploads` - File management

### Admin Features
- Contact status tracking (new, contacted, resolved)
- Newsletter subscriber management
- File upload with type categorization
- Project portfolio management

## 🔐 Admin Panel Access

Access the admin panel at `/admin/` with the following features:

### Dashboard
- Real-time statistics
- Recent submissions overview
- Performance metrics

### Contact Management
- View all contact submissions
- Update inquiry status
- Export contact data

### Newsletter Management
- Subscriber list management
- Activation/deactivation controls
- Export subscriber data

### File Management
- Upload brochures and documents
- Categorize files by type
- Download and delete files

## 🎨 Customization

### Styling
- Edit `static/css/style.css` for custom styles
- Bootstrap 5 classes available throughout
- CSS custom properties for theming

### Content Updates
- Service pages in `templates/services/`
- Homepage content in `templates/index.html`
- Legal pages in `templates/legal/`

### Functionality
- Add new routes in `routes.py`
- Extend models in `models.py`
- Add admin features in `admin.py`

## 🔒 Security Features

- CSRF protection on all forms
- Secure file upload validation
- SQL injection prevention via ORM
- XSS protection with template escaping
- Secure session management

## 📊 Analytics & Monitoring

- Contact submission tracking
- Newsletter subscription metrics
- File upload monitoring
- Performance statistics

## 🌐 SEO Features

- Semantic HTML structure
- Meta tag optimization
- Open Graph tags
- Structured data markup
- Mobile-responsive design

## 🚀 Deployment

### cPanel Hosting
1. Upload files via File Manager
2. Create PostgreSQL database
3. Set environment variables
4. Configure Python app

### VPS/Cloud Deployment
1. Install dependencies
2. Configure reverse proxy (Nginx)
3. Set up SSL certificate
4. Configure systemd service

## 🔧 Maintenance

### Regular Tasks
- Database backups
- Log monitoring
- Security updates
- Performance optimization

### Backup Commands
```bash
# Database backup
pg_dump nikoji_tech_db > backup_$(date +%Y%m%d).sql

# File backup
tar -czf files_backup_$(date +%Y%m%d).tar.gz static/uploads/
```

## 📞 Support & Contact

For technical support and inquiries:
- Email: support@nikoji.com
- Phone: +1-XXX-XXX-XXXX
- Website: https://nikoji.com

## 📄 License

© 2024 Nikoji Technologies. All rights reserved.

## 🔄 Version History

- v1.0.0 - Initial release with core functionality
- v1.1.0 - Added admin panel and file management
- v1.2.0 - Enhanced contact management and analytics

---

Built with ❤️ by Nikoji Technologies