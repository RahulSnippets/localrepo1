from app import app, db

# Import models and routes after app initialization
with app.app_context():
    import models  # noqa: F401
    import routes  # noqa: F401
    
    # Import and register admin blueprint
    from admin import admin_bp
    app.register_blueprint(admin_bp)
    
    # Create database tables
    db.create_all()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
