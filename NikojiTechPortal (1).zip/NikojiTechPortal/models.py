from app import db
from datetime import datetime
from sqlalchemy import Text

class ContactSubmission(db.Model):
    """Model for storing contact form submissions"""
    __tablename__ = 'contact_submissions'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    company = db.Column(db.String(100), nullable=True)
    service = db.Column(db.String(50), nullable=True)
    message = db.Column(Text, nullable=False)
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    status = db.Column(db.String(20), default='new', nullable=False)  # new, contacted, resolved
    
    def __repr__(self):
        return f'<ContactSubmission {self.name} - {self.email}>'

class NewsletterSubscriber(db.Model):
    """Model for storing newsletter subscribers"""
    __tablename__ = 'newsletter_subscribers'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    subscribed_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    
    def __repr__(self):
        return f'<NewsletterSubscriber {self.email}>'

class Project(db.Model):
    """Model for storing project information"""
    __tablename__ = 'projects'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(Text, nullable=False)
    category = db.Column(db.String(50), nullable=False)  # automation, software, design, ems
    technologies = db.Column(db.String(500), nullable=True)  # JSON string or comma-separated
    client_name = db.Column(db.String(100), nullable=True)
    project_date = db.Column(db.Date, nullable=True)
    status = db.Column(db.String(20), default='completed', nullable=False)  # completed, ongoing, planned
    featured = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    
    def __repr__(self):
        return f'<Project {self.title}>'

class ServiceInquiry(db.Model):
    """Model for storing service-specific inquiries"""
    __tablename__ = 'service_inquiries'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    company = db.Column(db.String(100), nullable=True)
    service_type = db.Column(db.String(50), nullable=False)
    project_scope = db.Column(Text, nullable=True)
    budget_range = db.Column(db.String(50), nullable=True)
    timeline = db.Column(db.String(50), nullable=True)
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    status = db.Column(db.String(20), default='new', nullable=False)
    
    def __repr__(self):
        return f'<ServiceInquiry {self.name} - {self.service_type}>'

class Testimonial(db.Model):
    """Model for storing client testimonials"""
    __tablename__ = 'testimonials'
    
    id = db.Column(db.Integer, primary_key=True)
    client_name = db.Column(db.String(100), nullable=False)
    company = db.Column(db.String(100), nullable=False)
    position = db.Column(db.String(100), nullable=True)
    testimonial_text = db.Column(Text, nullable=False)
    rating = db.Column(db.Integer, nullable=True)  # 1-5 stars
    project_type = db.Column(db.String(50), nullable=True)
    is_featured = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    
    def __repr__(self):
        return f'<Testimonial {self.client_name} - {self.company}>'

class FileUpload(db.Model):
    """Model for storing uploaded files"""
    __tablename__ = 'file_uploads'
    
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    original_filename = db.Column(db.String(255), nullable=False)
    file_path = db.Column(db.String(500), nullable=False)
    file_type = db.Column(db.String(100), nullable=False)
    file_size = db.Column(db.Integer, nullable=False)
    uploaded_by = db.Column(db.String(100), nullable=True)
    upload_type = db.Column(db.String(50), nullable=False)  # brochure, project_image, testimonial_image, general
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    
    def __repr__(self):
        return f'<FileUpload {self.original_filename}>'