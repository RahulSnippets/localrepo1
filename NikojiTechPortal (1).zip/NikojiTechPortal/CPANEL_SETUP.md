# cPanel Deployment Guide for Nikoji Technologies Website

This guide provides step-by-step instructions for deploying the Nikoji Technologies Flask website to a cPanel hosting environment.

## Prerequisites

- cPanel hosting account with Python support (3.8+)
- PostgreSQL database access
- Domain name configured
- FTP/File Manager access

## Step 1: Database Setup

### 1.1 Create PostgreSQL Database
1. Log into cPanel
2. Navigate to "PostgreSQL Databases"
3. Create a new database: `yourusername_nikoji_tech`
4. Create a database user: `yourusername_nikoji_user`
5. Set a strong password
6. Add user to database with full privileges

### 1.2 Note Database Credentials
```
Database Name: yourusername_nikoji_tech
Database User: yourusername_nikoji_user
Database Password: [your_password]
Database Host: localhost
Database Port: 5432
```

## Step 2: File Upload

### 2.1 Upload Project Files
Using cPanel File Manager or FTP client:

1. **Upload all Python files to your domain root:**
   ```
   public_html/
   ├── app.py
   ├── main.py
   ├── routes.py
   ├── models.py
   ├── forms.py
   ├── admin.py
   └── .env
   ```

2. **Upload static files:**
   ```
   public_html/static/
   ├── css/
   │   └── style.css
   ├── js/
   │   └── main.js
   ├── images/
   │   └── logo.png
   └── uploads/ (create empty directory)
   ```

3. **Upload templates:**
   ```
   public_html/templates/
   ├── base.html
   ├── index.html
   ├── contact.html
   ├── admin/
   └── [all other template files]
   ```

### 2.2 Set File Permissions
- Directories: 755 (drwxr-xr-x)
- Python files: 644 (-rw-r--r--)
- Upload directory: 755 with write permissions

## Step 3: Environment Configuration

### 3.1 Create .env File
Create `.env` file in your domain root:

```env
# Flask Configuration
FLASK_ENV=production
FLASK_DEBUG=False
SESSION_SECRET=your-random-secret-key-minimum-32-characters

# Database Configuration (Update with your actual values)
DATABASE_URL=postgresql://yourusername_nikoji_user:your_password@localhost:5432/yourusername_nikoji_tech
PGHOST=localhost
PGPORT=5432
PGDATABASE=yourusername_nikoji_tech
PGUSER=yourusername_nikoji_user
PGPASSWORD=your_password

# Application Settings
UPLOAD_FOLDER=static/uploads
MAX_CONTENT_LENGTH=16777216
ALLOWED_EXTENSIONS=pdf,doc,docx,jpg,jpeg,png,gif

# Security Settings
WTF_CSRF_ENABLED=True
WTF_CSRF_TIME_LIMIT=3600
```

### 3.2 Secure .env File
Add to `.htaccess` in domain root:
```apache
<Files ".env">
    Order allow,deny
    Deny from all
</Files>
```

## Step 4: Python Application Setup

### 4.1 Create Python App in cPanel
1. Go to "Python App" in cPanel
2. Click "Create Application"
3. Set Python version: 3.8+ (latest available)
4. Set Application Root: `/public_html`
5. Set Application URL: your domain or subdomain
6. Set Application Startup File: `main.py`

### 4.2 Install Dependencies
In the Python App interface:

1. Click on your application
2. Go to "Modules" tab
3. Install these packages one by one:
   ```
   Flask==2.3.3
   Flask-SQLAlchemy==3.0.5
   Flask-WTF==1.1.1
   WTForms==3.0.1
   email-validator==2.0.0
   gunicorn==21.2.0
   psycopg2-binary==2.9.7
   Werkzeug==2.3.7
   python-dotenv==1.0.0
   ```

### 4.3 Configure Application Entry Point
Ensure your `main.py` contains:
```python
from app import app

if __name__ == '__main__':
    app.run()
```

## Step 5: Database Initialization

### 5.1 SSH Access (if available)
If you have SSH access:
```bash
cd public_html
python3 -c "from app import app, db; app.app_context().push(); db.create_all()"
```

### 5.2 Alternative: Web-based Initialization
Create a temporary initialization script `init_db.py`:
```python
from app import app, db

with app.app_context():
    try:
        db.create_all()
        print("Database tables created successfully!")
    except Exception as e:
        print(f"Error creating tables: {e}")
```

Run once through cPanel Python App interface, then delete the file.

## Step 6: Configure Web Server

### 6.1 Update .htaccess
Create or update `.htaccess` in domain root:
```apache
# Redirect all requests to Python app
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ /main.py/$1 [QSA,L]

# Security headers
Header always set X-Content-Type-Options nosniff
Header always set X-Frame-Options DENY
Header always set X-XSS-Protection "1; mode=block"
Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains"

# Protect sensitive files
<Files ".env">
    Order allow,deny
    Deny from all
</Files>

<Files "*.py">
    Order allow,deny
    Deny from all
</Files>
```

### 6.2 Static Files Configuration
Ensure static files are served directly:
```apache
# Allow static files
<Directory "static">
    Order allow,deny
    Allow from all
</Directory>
```

## Step 7: SSL Certificate Setup

### 7.1 Enable SSL
1. Go to "SSL/TLS" in cPanel
2. Select "Let's Encrypt" or upload your certificate
3. Enable "Force HTTPS Redirect"

### 7.2 Update Application for HTTPS
In `app.py`, add:
```python
if not app.debug:
    app.config['PREFERRED_URL_SCHEME'] = 'https'
```

## Step 8: Testing and Verification

### 8.1 Test Website Functionality
1. Visit your domain
2. Test navigation between pages
3. Submit contact form
4. Subscribe to newsletter
5. Access admin panel at `/admin/`

### 8.2 Test Admin Panel
1. Navigate to `/admin/`
2. Test contact management
3. Upload brochure files
4. Verify file downloads

### 8.3 Performance Testing
- Check page load times
- Verify database connections
- Test file upload functionality
- Monitor error logs

## Step 9: Security Hardening

### 9.1 File Permissions
```bash
find public_html -type d -exec chmod 755 {} \;
find public_html -type f -exec chmod 644 {} \;
chmod 600 .env
```

### 9.2 Database Security
- Use strong passwords
- Limit database user privileges
- Enable SSL for database connections (if available)

### 9.3 Application Security
- Keep dependencies updated
- Monitor access logs
- Set up regular backups
- Use strong session secrets

## Step 10: Maintenance

### 10.1 Regular Backups
Set up automated backups for:
- Database (PostgreSQL dump)
- Application files
- Uploaded files in `static/uploads/`

### 10.2 Monitoring
- Set up error logging
- Monitor disk space usage
- Check database performance
- Review access logs regularly

### 10.3 Updates
- Update Python packages regularly
- Monitor for security patches
- Test updates in staging environment first

## Troubleshooting

### Common Issues

1. **Application won't start:**
   - Check Python version compatibility
   - Verify all dependencies are installed
   - Check error logs in cPanel

2. **Database connection errors:**
   - Verify database credentials
   - Check PostgreSQL service status
   - Ensure user has proper privileges

3. **Static files not loading:**
   - Check file permissions
   - Verify .htaccess configuration
   - Ensure proper URL paths

4. **Upload functionality not working:**
   - Check upload directory permissions
   - Verify file size limits
   - Check disk space availability

### Error Log Locations
- Python app errors: cPanel > Python App > Logs
- Web server errors: cPanel > Error Logs
- Application logs: Check your Flask app configuration

### Performance Optimization
- Enable gzip compression
- Set up caching headers
- Optimize database queries
- Use CDN for static assets (optional)

## Support Resources

- cPanel Documentation
- Flask Documentation
- PostgreSQL Documentation
- Your hosting provider's support

## Contact Information

For technical support:
- Check hosting provider documentation
- Contact hosting support team
- Review Flask and PostgreSQL communities

---

**Note:** Replace `yourusername_` with your actual cPanel username throughout this guide.

**Security Notice:** Always keep your `.env` file secure and never commit it to version control.