from flask import render_template, request, flash, redirect, url_for
from app import app, db
from forms import ContactForm, NewsletterForm
from models import ContactSubmission, NewsletterSubscriber
from sqlalchemy.exc import IntegrityError

@app.route('/')
def index():
    """Homepage with hero section, services, stats, and testimonials"""
    return render_template('index.html')

@app.route('/automation')
def automation():
    """Automation services page"""
    return render_template('automation.html')

@app.route('/innovation')
def innovation():
    """Innovation services page"""
    return render_template('innovation.html')

@app.route('/design-development')
def design_development():
    """Design & Development services page"""
    return render_template('design_development.html')

@app.route('/testing-service')
def testing_service():
    """Testing & Service page"""
    return render_template('testing_service.html')

@app.route('/software-development')
def software_development():
    """Software Development services page"""
    return render_template('software_development.html')

@app.route('/requirements')
def requirements():
    """Requirements Gathering services page"""
    return render_template('requirements.html')

@app.route('/ems-solutions')
def ems_solutions():
    """EMS Solutions services page"""
    return render_template('ems_solutions.html')

@app.route('/consultancy')
def consultancy():
    """Consultancy services page"""
    return render_template('consultancy.html')

@app.route('/about')
def about():
    """About us page"""
    return render_template('about.html')

@app.route('/projects')
def projects():
    """Projects showcase page"""
    return render_template('projects.html')

@app.route('/privacy-policy')
def privacy_policy():
    """Privacy policy page"""
    return render_template('privacy-policy.html')

@app.route('/terms-of-service')
def terms_of_service():
    """Terms of service page"""
    return render_template('terms-of-service.html')

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    """Contact page with form handling"""
    form = ContactForm()
    if form.validate_on_submit():
        try:
            # Create new contact submission
            submission = ContactSubmission()
            submission.name = form.name.data
            submission.email = form.email.data
            submission.company = form.company.data or None
            submission.service = form.service.data
            submission.message = form.message.data
            db.session.add(submission)
            db.session.commit()
            app.logger.info(f'New contact submission from {form.email.data}')
            flash('Thank you for your message. We will get back to you soon!', 'success')
            # Clear form after successful submission
            return redirect(url_for('contact'))
        except Exception as e:
            db.session.rollback()
            app.logger.error(f'Error saving contact submission: {str(e)}')
            flash('There was an error processing your request. Please try again.', 'error')
    return render_template('contact.html', form=form)

@app.route('/newsletter', methods=['POST'])
def newsletter():
    """Newsletter signup handler"""
    form = NewsletterForm()
    if form.validate_on_submit():
        try:
            # Check if email already exists
            existing_subscriber = NewsletterSubscriber.query.filter_by(email=form.email.data).first()
            if existing_subscriber:
                if existing_subscriber.is_active:
                    flash('You are already subscribed to our newsletter!', 'info')
                else:
                    # Reactivate subscription
                    existing_subscriber.is_active = True
                    db.session.commit()
                    app.logger.info(f'Reactivated newsletter subscription for {form.email.data}')
                    flash('Welcome back! Your subscription has been reactivated.', 'success')
            else:
                # Create new subscriber
                subscriber = NewsletterSubscriber()
                subscriber.email = form.email.data
                db.session.add(subscriber)
                db.session.commit()
                app.logger.info(f'New newsletter subscription: {form.email.data}')
                flash('Thank you for subscribing to our newsletter!', 'success')
        except IntegrityError:
            db.session.rollback()
            flash('You are already subscribed to our newsletter!', 'info')
        except Exception as e:
            db.session.rollback()
            app.logger.error(f'Error saving newsletter subscription: {str(e)}')
            flash('There was an error processing your subscription. Please try again.', 'error')
    else:
        flash('Please enter a valid email address.', 'error')
    return redirect(request.referrer or url_for('index'))

@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('500.html'), 500
